<?php
/**
 * Base for cart widgets — the WooCommerce cart page design (desktop + mobile).
 * Real cart resolvers (items, totals, savings, shipping), money formatting,
 * editor demo data and shared control builders.
 *
 * @package HamiShop_Elementor_Widgets
 */

defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;

abstract class HSW_Cart_Base extends HSW_Widget_Base {

        public function get_categories() {
                return array( 'hamishop-cart' );
        }

        public function get_style_depends() {
                return array( 'hsw-fonts', 'hsw-cart' );
        }

        public function get_script_depends() {
                return array( 'hsw-cart' );
        }

        /* =========================================================================
         *  CONTEXT
         * ====================================================================== */

        /**
         * True when the live WooCommerce cart object is available.
         */
        protected function has_cart() {
                return function_exists( 'WC' ) && WC()->cart && function_exists( 'wc_get_cart_url' );
        }

        /**
         * Refresh a live cart immediately before displaying prices or rates.
         * WooCommerce can restore old cart_totals from the session even after
         * a shipping cache version change invalidates the package rates. Do not
         * touch an order being paid, an empty cart, or an editor demo. This is
         * deliberately scoped to price-bearing widgets, not every page load.
         */
        protected function refresh_display_cart() {
                if ( ! $this->has_cart() || $this->is_demo() || WC()->cart->is_empty() || $this->paying_order() ) {
                        return;
                }
                WC()->cart->calculate_totals();
        }

        /**
         * The order being paid on an order-pay screen, or null.
         *
         * `?pay_for_order=true` empties the cart: everything the summary needs is
         * on the order. Without this the wallet top-up page (and every retried
         * payment) printed «جمع قیمت اقلام (۰): ۰ تومان» and «مبلغ قابل پرداخت:
         * ۰ تومان» while the gateway was about to charge the real total — the
         * customer was looking at a free order.
         *
         * @return WC_Order|null
         */
        protected function paying_order() {
                if ( ! function_exists( 'wc_get_order' ) ) {
                        return null;
                }

                global $wp;

                $id = isset( $wp->query_vars['order-pay'] ) ? absint( $wp->query_vars['order-pay'] ) : 0;

                /*
                 * After «ادامه و ورود به مرحله پرداخت» the URL is the pay page, not
                 * `/order-pay/<id>/`, and the order only lives in the session. Use
                 * it when the cart is empty — that is exactly the case where there
                 * is nothing else to show. With a cart (the normal checkout step)
                 * the cart stays the source of truth, so a customer who comes back
                 * to edit quantities never sees a stale order total.
                 */
                if ( ! $id && $this->uses_order_fallback() && function_exists( 'WC' ) && WC()->session ) {
                        $empty_cart = ! WC()->cart || 0 === (int) WC()->cart->get_cart_contents_count();
                        if ( $empty_cart ) {
                                $id = absint( WC()->session->get( 'order_awaiting_payment' ) );
                        }
                }

                if ( ! $id ) {
                        return null;
                }

                $order = wc_get_order( $id );

                return $order instanceof WC_Order ? $order : null;
        }

        /**
         * May this widget render the order awaiting payment instead of the cart?
         *
         * The pay and checkout steps need it: their cart is empty by design and
         * the order is the only thing left to show. Cart widgets must not.
         *
         * A cart page that renders an order is a cart page that lies — and it
         * produced a broken layout. After a payment was abandoned at the
         * gateway, the cart was empty while `order_awaiting_payment` still
         * pointed at the pending order. `HSW_Widget_Cart_Page` asked the cart
         * whether it was empty (yes), chose the one-column empty-state grid and
         * returned before the summary; the items widget then asked a different
         * question, found the order, and drew its line inside that empty state.
         * The customer saw a narrow centred card with a product and no totals,
         * no coupon and no button. Two parts, two answers, one broken page.
         *
         * Cart widgets now answer "no" and the page stays coherent: empty cart,
         * empty state, and the pending order is left where it belongs.
         *
         * @return bool
         */
        protected function uses_order_fallback() {
                return true;
        }

        /**
         * Line items of the order being paid, in the same shape as cart items.
         *
         * Fees are included on purpose: a wallet top-up order is a single fee and
         * no products, and a summary that ignores it shows zero for the only
         * thing the customer is paying for.
         *
         * @param WC_Order $order Order being paid.
         * @return array<int,array<string,mixed>>
         */
        protected function order_lines( $order ) {
                $rows = array();

                foreach ( $order->get_items() as $item ) {
                        $product = method_exists( $item, 'get_product' ) ? $item->get_product() : null;
                        $total   = (float) $item->get_total() + (float) $item->get_total_tax();

                        $rows[] = array(
                                'key'      => 'order-' . $item->get_id(),
                                'name'     => $item->get_name(),
                                'url'      => $product ? $product->get_permalink() : '',
                                'img'      => $product ? $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ) : '',
                                'eyebrow'  => '',
                                'chips'    => array(),
                                'warranty' => '',
                                'qty'      => (int) $item->get_quantity(),
                                'min'      => 1,
                                'max'      => 0,
                                'price'    => $total,
                                'regular'  => $total,
                                'disc'     => 0,
                                'remove'   => '',
                        );
                }

                foreach ( $order->get_fees() as $fee ) {
                        $total = (float) $fee->get_total() + (float) $fee->get_total_tax();

                        $rows[] = array(
                                'key'      => 'fee-' . $fee->get_id(),
                                'name'     => $fee->get_name(),
                                'url'      => '',
                                'img'      => '',
                                'eyebrow'  => '',
                                'chips'    => array(),
                                'warranty' => '',
                                'qty'      => 1,
                                'min'      => 1,
                                'max'      => 0,
                                'price'    => $total,
                                'regular'  => $total,
                                'disc'     => 0,
                                'remove'   => '',
                        );
                }

                return $rows;
        }

        /**
         * True while inside the Elementor editor / preview iframe (any context).
         */
        protected function is_editing() {
                if ( ! class_exists( '\Elementor\Plugin' ) ) {
                        return false;
                }
                $el = \Elementor\Plugin::$instance;
                return ( isset( $el->editor ) && $el->editor->is_edit_mode() )
                        || ( isset( $el->preview ) && $el->preview->is_preview_mode() )
                        || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() && isset( $_POST['action'] ) && 'elementor_ajax' === $_POST['action'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        }

        /**
         * Editor / ajax preview without a real cart → render the design demo.
         */
        protected function is_demo() {
                if ( $this->has_cart() ) {
                        return false;
                }
                return $this->is_editing();
        }

        /**
         * Value of a widget option with default fallback.
         */
        protected function opt( $key, $default = '' ) {
                $s = $this->effective_settings();
                return ( isset( $s[ $key ] ) && '' !== trim( (string) $s[ $key ] ) ) ? trim( (string) $s[ $key ] ) : $default;
        }

        /**
         * Root classes for cart widgets.
         */
        protected function root_class( $slug, $extra = '' ) {
                $s   = $this->effective_settings();
                $vis = isset( $s['vis'] ) ? sanitize_html_class( $s['vis'] ) : 'auto';
                $cls = 'hsw-c hsw-' . $slug . ' hsw-vis-' . $vis . $this->hsw_font_class();
                if ( $extra ) {
                        $cls .= ' ' . $extra;
                }
                return $cls;
        }

        /**
         * Cart URL (form action) — safe '#' inside the editor demo.
         */
        protected function cart_url() {
                return $this->has_cart() ? wc_get_cart_url() : '#';
        }

        /**
         * Checkout URL.
         */
        protected function checkout_url() {
                if ( $this->has_cart() && function_exists( 'wc_get_checkout_url' ) ) {
                        return wc_get_checkout_url();
                }
                return '#';
        }

        /**
         * Shop URL (back links).
         */
        protected function shop_url() {
                if ( function_exists( 'wc_get_page_permalink' ) ) {
                        return wc_get_page_permalink( 'shop' );
                }
                return home_url( '/' );
        }

        /* =========================================================================
         *  MONEY / NUMBERS (respect the shop currency config, Persian digits)
         * ====================================================================== */

        /**
         * Format an amount exactly like the design: ۶۵,۷۶۰,۰۰۰ + currency symbol.
         *
         * @param float $amount      Amount.
         * @param bool  $with_symbol Append the configured currency symbol.
         * @param bool  $minus_after Persian-style minus after digits (سود شما).
         */
        protected function money( $amount, $with_symbol = false, $minus_after = false ) {
                $decimals = function_exists( 'wc_get_price_decimals' ) ? absint( wc_get_price_decimals() ) : 0;
                $amount   = (float) $amount;

                /* WooCommerce exposes *_separator() — the short *_sep() names
                 * do not exist and fataled with "Call to undefined function". */
                $dec_sep   = function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : '.';
                $thou_sep  = function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : ',';
                $formatted = number_format( abs( $amount ), $decimals, $dec_sep, $thou_sep );
                $out       = HSW_Helpers::fa_num( $formatted );
                if ( $minus_after && 0.0 > $amount ) {
                        $out .= '-';
                }
                if ( $with_symbol ) {
                        $pos  = get_option( 'woocommerce_currency_pos', 'right' );
                        $sym  = get_woocommerce_currency_symbol();
                        $unit = ' <span class="hsw-c-cur">' . esc_html( $sym ) . '</span>';
                        $out  = ( 'right' === $pos || 'right_space' === $pos ) ? $out . $unit : $unit . ' ' . $out;
                }
                return $out;
        }

        /**
         * Count with Persian digits ({count} template helper).
         */
        protected function fa_count( $n ) {
                return HSW_Helpers::fa_num( (int) $n );
        }

        /**
         * Replace {count} in a label template.
         */
        protected function with_count( $template, $count ) {
                return str_replace( '{count}', $this->fa_count( $count ), (string) $template );
        }

        /* =========================================================================
         *  LIVE CART RESOLVERS
         * ====================================================================== */

        /**
         * Number of units in the cart.
         */
        protected function cart_count() {
                if ( $order = $this->paying_order() ) {
                        $count = 0;
                        foreach ( $this->order_lines( $order ) as $line ) {
                                $count += (int) $line['qty'];
                        }
                        return $count;
                }

                if ( ! $this->has_cart() ) {
                        return 0;
                }
                return (int) WC()->cart->get_cart_contents_count();
        }

        /**
         * Normalized cart items (array of render payloads).
         */
        protected function cart_items() {
                if ( $order = $this->paying_order() ) {
                        return $this->order_lines( $order );
                }

                if ( ! $this->has_cart() ) {
                        return array();
                }
                $items = array();
                foreach ( array_values( WC()->cart->get_cart() ) as $cart_item ) {
                        $data = $this->item_data( $cart_item );
                        if ( $data ) {
                                $items[] = $data;
                        }
                }
                return $items;
        }

        /**
         * Convert one cart item into a render payload.
         */
        protected function item_data( $cart_item ) {
                $product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;
                if ( ! $product instanceof WC_Product ) {
                        return null;
                }
                $qty          = ( $cart_item['quantity'] ) ? (int) $cart_item['quantity'] : 1;
                $price_unit   = (float) wc_get_price_to_display( $product, array( 'price' => $product->get_price( 'edit' ) ) );
                $regular_unit = 0;
                if ( $product->is_on_sale() && (float) $product->get_regular_price( 'edit' ) > (float) $product->get_price( 'edit' ) ) {
                        $regular_unit = (float) wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price( 'edit' ) ) );
                }
                $max = $product->get_max_purchase_quantity();
                return array(
                        'key'      => $cart_item['key'],
                        'name'     => $product->get_name(),
                        'url'      => $product->get_permalink( $cart_item ),
                        'img'      => $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ),
                        'eyebrow'  => HSW_Helpers::brand_label( $product ),
                        'chips'    => $this->item_chips( $cart_item, $product ),
                        'warranty' => $this->item_warranty( $product ),
                        'qty'      => $qty,
                        'min'      => 1,
                        'max'      => ( 0 < $max ) ? $max : 0,
                        'price'    => $price_unit * $qty,
                        'regular'  => $regular_unit * $qty,
                        'disc'     => HSW_Helpers::discount_percent( $product ),
                        'remove'   => function_exists( 'wc_get_cart_remove_url' ) ? wc_get_cart_remove_url( $cart_item['key'] ) : '',
                );
        }

        /**
         * Variation attribute chips (+ color dot when a hex is resolvable).
         */
        protected function item_chips( $cart_item, $product ) {
                $chips     = array();
                $variation = ( isset( $cart_item['variation'] ) && is_array( $cart_item['variation'] ) ) ? $cart_item['variation'] : array();

                /*
                 * A simple product keeps the customer's colour/size in
                 * `hsw_picked` (HSW_Simple_Attributes) because WooCommerce has no
                 * variation to hang it on. Print it like a variation chip so the
                 * cart line says which one was ordered.
                 */
                if ( class_exists( 'HSW_Simple_Attributes' ) && ! empty( $cart_item[ HSW_Simple_Attributes::KEY ] ) && is_array( $cart_item[ HSW_Simple_Attributes::KEY ] ) ) {
                        foreach ( $cart_item[ HSW_Simple_Attributes::KEY ] as $tax => $row ) {
                                if ( empty( $row['value'] ) ) {
                                        continue;
                                }
                                $hex = '';
                                if ( taxonomy_exists( (string) $tax ) && ! empty( $row['slug'] ) ) {
                                        $term = get_term_by( 'slug', (string) $row['slug'], (string) $tax );
                                        if ( $term instanceof WP_Term ) {
                                                foreach ( array( 'color', 'hex', 'color_hex', 'wpcsw_color' ) as $meta_key ) {
                                                        $meta = class_exists( 'HSW_Helpers' ) ? HSW_Helpers::css_color( get_term_meta( $term->term_id, $meta_key, true ) ) : '';
                                                        if ( '' !== $meta ) {
                                                                $hex = $meta;
                                                                break;
                                                        }
                                                }
                                                if ( '' === $hex && class_exists( 'HSW_Helpers' ) ) {
                                                        $hex = HSW_Helpers::color_from_name( $term->name );
                                                }
                                        }
                                }
                                if ( '' === $hex && class_exists( 'HSW_Helpers' ) ) {
                                        $hex = HSW_Helpers::color_from_name( (string) $row['value'] );
                                }
                                $chips[] = array(
                                        'label' => (string) $row['value'],
                                        'hex'   => $hex,
                                        'icon'  => '',
                                );
                        }
                }

                foreach ( $variation as $attr => $value ) {
                        if ( '' === $value || null === $value ) {
                                continue;
                        }
                        $value   = (string) $value;
                        $tax     = ( 0 === strpos( $attr, 'attribute_pa_' ) ) ? substr( $attr, strlen( 'attribute_' ) ) : '';
                        $display = $value;
                        $hex     = '';
                        /* Variation keys may encode a Persian taxonomy while WP
                         * registers its decoded spelling. Resolve the real name
                         * just as the product picker does; do not change the cart. */
                        $real_tax = '';
                        if ( $tax ) {
                                $decoded_tax = rawurldecode( $tax );
                                foreach ( array_unique( array( $tax, $decoded_tax, sanitize_title( $decoded_tax ) ) ) as $candidate ) {
                                        if ( taxonomy_exists( $candidate ) ) {
                                                $real_tax = $candidate;
                                                break;
                                        }
                                }
                        }
                        if ( $real_tax ) {
                                $term = get_term_by( 'slug', $value, $real_tax );
                                if ( ! $term instanceof WP_Term ) {
                                        $decoded_value = rawurldecode( $value );
                                        foreach ( array_unique( array( $decoded_value, sanitize_title( $decoded_value ) ) ) as $candidate ) {
                                                if ( $candidate === $value ) {
                                                        continue;
                                                }
                                                $term = get_term_by( 'slug', $candidate, $real_tax );
                                                if ( $term instanceof WP_Term ) {
                                                        break;
                                                }
                                        }
                                }
                                if ( $term instanceof WP_Term ) {
                                        $display = $term->name;
                                        foreach ( array( 'color', 'hex', 'color_hex', 'wpcsw_color' ) as $meta_key ) {
                                                $meta = get_term_meta( $term->term_id, $meta_key, true );
                                                /* rgb() counts too — Woodmart stores that shape. */
                                                $meta = class_exists( 'HSW_Helpers' ) ? HSW_Helpers::css_color( $meta ) : '';
                                                if ( '' !== $meta ) {
                                                        $hex = $meta;
                                                        break;
                                                }
                                        }
                                        if ( '' === $hex && class_exists( 'HSW_Helpers' ) ) {
                                                $hex = HSW_Helpers::color_from_name( $term->name );
                                        }
                                }
                        }
                        if ( '' === $hex && preg_match( '/^#[0-9a-fA-F]{3,8}$/', $value ) ) {
                                $hex = $value;
                        }
                        $chips[] = array(
                                'label' => $display,
                                'hex'   => $hex,
                                'icon'  => '',
                        );
                        unset( $product );
                }
                return $chips;
        }

        /**
         * Warranty/guarantee text from the product attributes (if any).
         */
        protected function item_warranty( $product ) {
                $attrs = $product->get_attributes();
                if ( empty( $attrs ) || ! is_array( $attrs ) ) {
                        return '';
                }
                foreach ( $attrs as $attr ) {
                        if ( ! $attr instanceof WC_Product_Attribute ) {
                                continue;
                        }
                        $name = strtolower( $attr->get_name() );
                        $hit  = ( false !== strpos( $name, 'warranty' ) || false !== strpos( $name, 'guarantee' ) )
                                || ( function_exists( 'mb_strtolower' ) && ( false !== mb_strpos( mb_strtolower( $attr->get_name() ), 'گارانتی' ) || false !== mb_strpos( mb_strtolower( $attr->get_name() ), 'ضمانت' ) ) );
                        if ( ! $hit ) {
                                continue;
                        }
                        $names = array();
                        $terms = $attr->get_terms();
                        if ( $terms && ! is_wp_error( $terms ) ) {
                                foreach ( $terms as $t ) {
                                        $names[] = $t->name;
                                }
                        } else {
                                $opts = $attr->get_options();
                                foreach ( (array) $opts as $opt ) {
                                        $names[] = (string) $opt;
                                }
                        }
                        $text = trim( implode( ' ', array_filter( $names ) ) );
                        if ( '' !== $text ) {
                                return $text;
                        }
                }
                return '';
        }

        /**
         * Base (regular-price) subtotal of the cart — «قیمت پایه اقلام».
         */
        protected function base_subtotal() {
                if ( $order = $this->paying_order() ) {
                        $sum = 0;
                        foreach ( $this->order_lines( $order ) as $line ) {
                                $sum += (float) $line['price'];
                        }
                        return $sum;
                }

                if ( ! $this->has_cart() ) {
                        return 0;
                }
                $sum = 0;
                foreach ( WC()->cart->get_cart() as $cart_item ) {
                        $product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;
                        if ( ! $product instanceof WC_Product ) {
                                continue;
                        }
                        $qty  = $cart_item['quantity'] ? (int) $cart_item['quantity'] : 1;
                        /*
                         * «قیمت پایه اقلام» is the pre-discount price: using the
                         * active price made the row equal to the sale subtotal and
                         * broke the base − savings = total relationship.
                         */
                        $base = (float) $product->get_regular_price( 'edit' );
                        if ( $base <= 0 ) {
                                $base = (float) $product->get_price( 'edit' );
                        }
                        $sum += (float) wc_get_price_to_display( $product, array( 'price' => $base ) ) * $qty;
                }
                return $sum;
        }

        /**
         * «سود شما از این خرید» = base subtotal − (total − shipping).
         */
        protected function savings() {
                if ( ! $this->has_cart() || ! class_exists( 'HSW_Helpers' ) ) {
                        return 0;
                }
                /*
                 * «سود شما از خرید» = تخفیف محصول (قیمت اصلی − قیمت فروش) + کوپن.
                 * The old base − (total − shipping) formula missed sale prices and
                 * counted payment fees against the customer, so the cart page and
                 * the checkout page showed different numbers.
                 */
                $saving = HSW_Helpers::savings();

                return (float) ( $saving['total'] ?? 0 );
        }

        /**
         * Shipping row state: [ state, cost ].
         *
         * `free`        — a rate is chosen and it really costs nothing.
         * `amount`      — a rate is chosen and has a price.
         * `pending`     — shipping is needed but nothing is chosen yet.
         * `none`        — the cart does not need shipping (digital only).
         * `unavailable` — no rate exists for this destination.
         *
         * The old version answered `( $ship > 0 ) ? 'amount' : 'free'`, so a
         * zero total meant "free". Zero also means "not calculated yet", "no
         * rate for this address" and "nothing to ship" — and the summary told
         * the customer «رایگان» in all four cases. With a destination outside
         * every zone that is a promise the shop cannot keep.
         *
         * @return array{0:string,1:float}
         */
        protected function shipping_state() {
                if ( $order = $this->paying_order() ) {
                        return HSW_Shipping_State::for_order( $order );
                }

                if ( ! $this->has_cart() ) {
                        return array( HSW_Shipping_State::PENDING, 0.0 );
                }

                return HSW_Shipping_State::for_cart();
        }

        /**
         * Shipping row state (kept as the name the callers already use).
         *
         * @return array{0:string,1:float}
         */
        protected function shipping_row() {
                return $this->shipping_state();
        }

        /**
         * Customer-facing label for a shipping state that has no amount.
         *
         * @param string $state     State from shipping_state().
         * @param string $free_text Editable «رایگان» text ('' = default).
         * @return string
         */
        protected function shipping_state_label( $state, $free_text = '' ) {
                return HSW_Shipping_State::label( $state, $free_text );
        }

        /**
         * Final payable amount (get_total).
         */
        protected function cart_total() {
                if ( $order = $this->paying_order() ) {
                        return (float) $order->get_total();
                }

                if ( ! $this->has_cart() ) {
                        return 0;
                }
                return (float) WC()->cart->get_total( 'edit' );
        }

        /**
         * Total tax amount (0 when taxes disabled).
         */
        protected function taxes_total() {
                if ( $order = $this->paying_order() ) {
                        return (float) $order->get_total_tax();
                }

                if ( ! $this->has_cart() || ! wc_tax_enabled() ) {
                        return 0;
                }
                return (float) WC()->cart->get_taxes_total();
        }

        /* =========================================================================
         *  NONCE / FORM HELPERS
         * ====================================================================== */

        /**
         * WooCommerce cart nonce fields (update_cart verification).
         */
        protected function cart_nonce() {
                return wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce', true, false );
        }

        /**
         * Empty-cart nonce field (custom action).
         */
        protected function empty_nonce() {
                return wp_nonce_field( 'hsw-empty-cart', 'hsw_empty_cart_nonce', true, false );
        }

        /* =========================================================================
         *  DEMO DATA (editor preview only — mirrors the supplied mock)
         * ====================================================================== */

        protected function demo_items() {
                $ph = HSW_URL . 'assets/img/placeholder.svg';
                return array(
                        array(
                                'key'      => 'demo-1',
                                'name'     => 'گوشی موبایل سامسونگ Galaxy S24 Ultra 5G ظرفیت ۲۵۶ گیگابایت',
                                'url'      => '#',
                                'img'      => '<img src="' . esc_url( $ph ) . '" alt="" loading="lazy" />',
                                'eyebrow'  => 'گوشی هوشمند سامسونگ',
                                'chips'    => array(
                                        array( 'label' => 'مشکی تیتانیوم', 'hex' => '#2B2B2D', 'icon' => '' ),
                                        array( 'label' => '۲۵۶ گیگابایت', 'hex' => '', 'icon' => '' ),
                                ),
                                'warranty' => 'گارانتی ۱۸ ماهه شرکتی',
                                'qty'      => 1,
                                'min'      => 1,
                                'max'      => 5,
                                'price'    => 65760000,
                                'regular'  => 68500000,
                                'disc'     => 4,
                                'remove'   => '#',
                        ),
                        array(
                                'key'      => 'demo-2',
                                'name'     => 'شارژر دیواری سامسونگ ۴۵ وات اصل به همراه کابل Type-C',
                                'url'      => '#',
                                'img'      => '<img src="' . esc_url( $ph ) . '" alt="" loading="lazy" />',
                                'eyebrow'  => 'لوازم جانبی اورجینال',
                                'chips'    => array(
                                        array( 'label' => 'رنگ مشکی', 'hex' => '#000000', 'icon' => '' ),
                                ),
                                'warranty' => 'ضمانت ۶ ماهه تعویض اصالت کالا',
                                'qty'      => 1,
                                'min'      => 1,
                                'max'      => 10,
                                'price'    => 1450000,
                                'regular'  => 0,
                                'disc'     => 0,
                                'remove'   => '#',
                        ),
                );
        }

        protected function demo_totals() {
                return array(
                        'count'          => 2,
                        'base'           => 69950000,
                        'savings'        => 2740000,
                        'saving_product' => 2690000,
                        'saving_coupon'  => 50000,
                        'shipping'       => array( 'free', 0 ),
                        'taxes'          => 0,
                        'total'          => 67210000,
                );
        }

        /* =========================================================================
         *  SHARED CONTROLS (same builders as the archive suite)
         * ====================================================================== */

        protected function ctrl_visibility( $default = 'auto' ) {
                $this->add_control(
                        'vis',
                        array(
                                'label'   => __( 'نمایش در', 'hamishop-elementor-widgets' ),
                                'type'    => Controls_Manager::SELECT,
                                'default' => $default,
                                'options' => array(
                                        'auto'    => __( 'پیش‌فرض طرح', 'hamishop-elementor-widgets' ),
                                        'desktop' => __( 'فقط دسکتاپ', 'hamishop-elementor-widgets' ),
                                        'mobile'  => __( 'فقط موبایل', 'hamishop-elementor-widgets' ),
                                ),
                        )
                );
        }


}
