<?php
/**
 * Keep customer-specific screens out of page caches.
 *
 * The payment, checkout, cart and account widgets render data from the
 * WooCommerce session — cart totals, addresses, the customer's name. Page-cache
 * plugins (WP Rocket, LiteSpeed, W3TC, Cloudflare APO) only auto-exclude the
 * pages WooCommerce registers as its own (cart / checkout / my-account). A
 * custom `/payment/` page built from these widgets is *not* on that list, so the
 * rendered HTML of one visitor's session can be served to the next.
 *
 * `nocache_headers()` alone is not enough: those plugins look for the
 * `DONOTCACHEPAGE` constant, and they read it before any output — so it has to
 * be set on `template_redirect`, not while a widget renders.
 *
 * The check is one postmeta read on singular requests and nothing at all on
 * archives, so it costs nothing measurable.
 *
 * @package HamiShop_Elementor_Widgets
 */

defined( 'ABSPATH' ) || exit;

class HSW_Cache_Guard {

	/**
	 * Widget families whose output depends on the visitor.
	 *
	 * Matched against the Elementor data / post content of the current page.
	 */
	const PRIVATE_WIDGETS = array(
		'hsw-pay-',
		'hsw-checkout-',
		'hsw-complete-',
		'hsw-cart-',
		'hsw-account',
		/*
		 * Shortcode-rendered route pages. The setup screen creates these pages
		 * with a shortcode rather than Elementor data, so the widget needles
		 * above never matched them and /complete/ was cached for guests.
		 * Keep every shortcode the setup screen or account page can render.
		 */
		'[hamishop_complete',
		'[hamishop_payment',
		'[hamishop_pay',
		'[hamishop_account',
		'[hsw_account',
	);

	/** @var HSW_Cache_Guard|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', array( $this, 'maybe_disable_cache' ), 1 );
	}

	/**
	 * Mark the current request as uncacheable when it shows private data.
	 */
	public function maybe_disable_cache() {
		if ( ! $this->is_private_view() && ! $this->is_filtered_archive() ) {
			return;
		}

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		if ( ! defined( 'DONOTCACHEDB' ) ) {
			define( 'DONOTCACHEDB', true );
		}

		/* CDN / proxy layer. */
		if ( ! headers_sent() ) {
			nocache_headers();
			header( 'X-HSW-Private: 1' );
		}

		/* LiteSpeed reads its own constant; harmless when the plugin is absent. */
		do_action( 'litespeed_control_set_nocache', 'HamiShop: customer-specific screen' );
	}

	/**
	 * Is this a filtered product archive?
	 *
	 * A cached copy of `/shop/` served for `/shop/?filter_pa_color=red` looks
	 * exactly like a filter that "does nothing" — and the same happens when the
	 * customer then clicks «حذف همه». Filtered archives are cheap to build and
	 * different for every visitor, so they must never come from the page cache.
	 *
	 * @return bool
	 */
	private function is_filtered_archive() {
		if ( empty( $_GET ) || ! is_array( $_GET ) ) {
			return false;
		}
		if ( ! function_exists( 'is_shop' ) ) {
			return false;
		}
		$is_archive = is_shop() || ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() );
		if ( ! $is_archive ) {
			return false;
		}

		$plain = array( 'instock', 'express', 'onsale', 'rating_filter', 'min_price', 'max_price', 'orderby', 'paged' );
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- public archive filters.
		foreach ( array_keys( $_GET ) as $key ) {
			if ( ! is_string( $key ) ) {
				continue;
			}
			if ( 0 === strpos( $key, 'filter_' ) || 0 === strpos( $key, 'query_type_' ) || in_array( $key, $plain, true ) ) {
				return true;
			}
		}
		// phpcs:enable

		return false;
	}

	/**
	 * Does this request render anything customer-specific?
	 *
	 * @return bool
	 */
	private function is_private_view() {
		/* WooCommerce's own pages — excluded by most caches already, but a
		   defensive check costs nothing and covers plugins that do not. */
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) {
			return true;
		}

		/* Order received / thank-you, including the custom complete route. */
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return true;
		}
		if ( get_query_var( 'order-received' ) ) {
			return true;
		}

		/*
		 * A completion URL always carries both values. Treat it as private even
		 * before the page-content check, because the order key itself is private
		 * and a cached copy of the page can be served with another visitor's key
		 * still in the URL.
		 */
		$request_order = isset( $_GET['order'] ) && is_scalar( $_GET['order'] ) ? trim( (string) wp_unslash( $_GET['order'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$request_key   = isset( $_GET['key'] ) && is_scalar( $_GET['key'] ) ? trim( (string) wp_unslash( $_GET['key'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' !== $request_order && '' !== $request_key ) {
			return true;
		}

		if ( ! is_singular() ) {
			return false;
		}

		$post_id = (int) get_queried_object_id();
		if ( ! $post_id ) {
			return false;
		}

		$haystack = (string) get_post_meta( $post_id, '_elementor_data', true );
		if ( '' === $haystack ) {
			$haystack = (string) get_post_field( 'post_content', $post_id );
		}
		if ( '' === $haystack ) {
			return false;
		}

		foreach ( self::PRIVATE_WIDGETS as $needle ) {
			if ( false !== strpos( $haystack, $needle ) ) {
				return true;
			}
		}

		return false;
	}
}
