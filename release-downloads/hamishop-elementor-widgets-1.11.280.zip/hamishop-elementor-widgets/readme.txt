=== HamiShop Elementor Widgets ===
Contributors: hamisys
Tags: elementor, woocommerce, widgets, product loop, rtl, persian
Requires at least: 6.0
Tested up to: 7.1.4
Requires PHP: 7.4
Stable tag: 1.11.280
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

۶۳ ویجت فروشگاهی فارسی و راست‌به‌چپ برای المنتور و ووکامرس: لوپ محصول، صفحه محصول، هدر، سبد، تسویه، آرشیو، مجله و پنل حساب کاربری — با پالت رنگی سراسری، فونت لوکال و بارگذاری شرطی.

== Description ==

HamiShop مجموعه‌ای از ویجت‌های المنتور است که صفحه‌های یک فروشگاه ووکامرس را بدون کدنویسی می‌سازد. هر ویجت یک بخش واقعی از فروشگاه است، نه یک بلوک تزئینی: داده را از خود ووکامرس می‌خواند، با هندلرهای بومی کار می‌کند و در نبود ووکامرس یا المنتور خطا نمی‌دهد.

= هفت خانواده، ۶۳ ویجت =

* **هدر و ناوبری (۴)** — هدر فروشگاهی با نوار اعلان، جستجوی محصول و مگامنو؛ هدر مینیمال شیشه‌ای؛ **هدر GC** با نوار شناور، نشان مدار و پنل‌های کشویی؛ فوتر چسبان موبایل.
* **لوپ محصولات (۳)** — پیشنهاد شگفت‌انگیز با شمارش معکوس، پرفروش‌ترین‌ها، محبوب‌ترین‌ها/منتخب با تب.
* **صفحه محصول (۱۲)** — گالری، بردکرامب، عنوان و متا، نوار اعتماد، ویژگی‌ها، انتخاب تنوع، جعبه خرید، تب‌ها، آکاردئون، نوار چسبان، محصولات مرتبط و صفحهٔ کامل محصول.
* **سبد خرید و پرداخت (۲۶)** — سبد، تسویه‌حساب، روش‌های پرداخت، فاکتور، تکمیل سفارش و صفحه‌های کامل هر مرحله.
* **آرشیو محصولات (۸)** — هدر آرشیو، فیلترها، نوار ابزار، گرید، راهنما، بردکرامب، صفحه‌بندی و صفحهٔ کامل آرشیو.
* **مجله و وبلاگ (۹)** — هیرو، مقالهٔ ویژه، گرید، تب‌ها، محبوب‌ها، برچسب‌ها، خبرنامه و صفحهٔ کامل نوشته.
* **حساب کاربری (۱)** — پنل کامل مشتری روی اندپوینت‌های واقعی ووکامرس.

= چیزهایی که در همهٔ ویجت‌ها مشترک است =

* **پالت رنگی سراسری:** یک صفحه در پیشخوان (HamiShop ← پالت رنگی) رنگ‌های اصلی، تاکید، مراحل خرید، متن، سطح‌ها، وضعیت‌ها و آیکون‌های هدر را تعیین می‌کند. کنترل رنگی هر ویجت، اگر تنظیم شود، بر پالت اولویت دارد.
* **فونت:** وزیرمتن به‌صورت متغیر و لوکال داخل افزونه است؛ هر فونت دیگری که روی سایت لود شده باشد از فهرست پالت یا با نوشتن نام دقیق آن قابل انتخاب است.
* **آیکون‌ها:** SVG درون‌صفحه (۱۰۱ آیکون) — بدون فونت آیکون و بدون درخواست خارجی. هر صفحه فقط نمادهایی را چاپ می‌کند که همان صفحه رندر کرده است.
* **بارگذاری شرطی:** CSS و JS هر خانواده فقط وقتی لود می‌شوند که ویجتی از آن خانواده در صفحه باشد.
* **بدون فریم‌ورک:** بدون jQuery، بدون Tailwind، بدون CDN. صفر درخواست خارجی.
* **راست‌به‌چپ و فارسی:** ارقام فارسی، تاریخ شمسی (اختیاری) و چیدمان RTL در همهٔ خانواده‌ها.
* **کنترل ویجت‌ها:** صفحهٔ HamiShop ← کنترل ویجت‌ها تعیین می‌کند کدام ویجت در پنل المنتور دیده شود. ۱۶ ویجت اصلی پیش‌فرض روشن‌اند و ۴۷ بخش مستقل پیش‌فرض خاموش.

= سازگاری =

* **Hami Call for Price:** اگر افزونهٔ CFP فعال باشد، محصولات علامت‌خورده در همهٔ سطوح HamiShop به‌جای قیمت و دکمهٔ خرید، متن و اکشن تماس همان افزونه را نشان می‌دهند. هندلرهای ووکامرس دست‌نخورده می‌مانند.
* **افزونه‌های ورود پیامکی/OTP:** اگر افزونهٔ دیگری احراز هویت را در دست بگیرد، فرم ورود HamiShop کنار می‌رود و دخالت نمی‌کند.
* **HPOS ووکامرس:** سازگاری اعلام‌شده؛ همهٔ سفارش‌ها از `wc_get_order()` خوانده می‌شوند.
* **LiteSpeed و بهینه‌سازها:** دارایی‌های افزونه از ادغام و UCSS خارج می‌شوند تا چیدمان و فونت به‌هم نریزد.

= دربارهٔ عملکرد =

افزونه دارایی‌های خودش را سبک و شرطی نگه می‌دارد، اما امتیاز Lighthouse یک عدد ثابت نیست: به قالب، محتوا، سرعت سرور و افزونه‌های دیگر بستگی دارد. جزئیات و روش اندازه‌گیری در مستندات مخزن آمده است.

== Installation ==

1. ZIP آمادهٔ نصب را از صفحهٔ Releases بردارید (فایل `hamishop-elementor-widgets-<version>.zip`). از گزینهٔ «Download ZIP» در صفحهٔ کد استفاده نکنید؛ آن فایل سورس است و ساختار پوشهٔ نصبی را ندارد.
2. پیشخوان ← افزونه‌ها ← افزودن ← بارگذاری افزونه ← همان ZIP را انتخاب کنید.
3. WooCommerce و Elementor باید نصب و فعال باشند.
4. در المنتور، دستهٔ «حامی» را باز کنید و ویجت موردنظر را بکشید.
5. رنگ‌ها و فونت را یک‌بار در HamiShop ← پالت رنگی تنظیم کنید.

== Frequently Asked Questions ==

= آیا به قالب خاصی وابسته است؟ =

نه. با هر قالبی که المنتور را پشتیبانی کند کار می‌کند؛ استایل‌ها داخل محدودهٔ خود ویجت هستند و به قالب نشت نمی‌کنند.

= ویجت‌های صفحه محصول را چطور اضافه کنم؟ =

یا از ویجت‌های تک‌بخشی استفاده کنید، یا ویجت «صفحهٔ کامل محصول» را بکشید و همهٔ بخش‌ها را با یک ویجت بگیرید.

= چرا بعضی ویجت‌ها در پنل المنتور نیستند؟ =

بخش‌های مستقل (۴۷ مورد) پیش‌فرض خاموش‌اند تا پنل شلوغ نشود. از HamiShop ← کنترل ویجت‌ها روشنشان کنید.

= داده‌های من با آپدیت از بین می‌رود؟ =

نه. ویجت‌ها، تنظیمات صفحه‌ها و پالت رنگی جای دیگری ذخیره می‌شوند و آپدیت فقط کد را عوض می‌کند. پاک‌سازی کش‌ها در پس‌زمینه و مرحله‌ای انجام می‌شود.

== Changelog ==

= 1.11.280 =
* ویجت «پیشنهاد شگفت‌انگیز» در حالت تمام‌عرض حالا گاتر کناری واقعی دارد: `clamp(16px, 5%, 96px)` روی پوستهٔ ویجت. هدر و اولین/آخرین کارت دیگر به لبهٔ سکشن نمی‌چسبند و پس‌زمینهٔ گرادیانی همچنان تا لبه می‌رود.
* ویجت‌های «محبوب‌ترین‌ها / منتخب» و «پرفروش‌ترین‌ها» هم داخل کادر خود گاتر `clamp(16px, 3%, 32px)` گرفتند؛ هدر و ریل دیگر روی حاشیهٔ کارت نمی‌نشینند.
* این تغییرها فقط به همین سه ویجت محدودند؛ loop-box/loop-deal و سایر بخش‌ها دست‌نخورده‌اند.

= 1.11.279 =
* تأیید ایمیل سفارش: بررسی throttle با HSW_Throttle::peek حالا قبل از مقایسهٔ ایمیل انجام می‌شود. وقتی باکت verify_order:{order_id}:{ip} یا verify_order_all:{order_id} پر باشد، حتی ایمیل درست هم 429 با Retry-After می‌گیرد؛ فقط شکست‌ها شمرده می‌شوند و ایمیل درست در حالت عادی باکت‌ها را پاک می‌کند.
* تست رگرسیون: بعد از پنج خطا، ایمیل غلط ششم و ایمیل درست هر دو 429؛ IP دیگر مستقل؛ و پس از پایان پنجره ایمیل درست دوباره پذیرفته می‌شود.

= 1.11.278 =
* رفع کش صفحهٔ /complete/ و مسیرهای شورت‌کدی: صفحه‌هایی که setup-pages با [hamishop_complete]، [hamishop_payment] یا [hamishop_account] می‌سازد حالا خصوصی تشخیص داده می‌شوند؛ درخواست دارای order و key هم همیشه no-cache است (Cache-Control: no-store/private و X-HSW-Private: 1).
* فرم تأیید ایمیل سفارش از رندر ویجت به template_redirect منتقل شد: موفقیت کوکی می‌گذارد و با 303 به همان URL برمی‌گردد (PRG)؛ خطا بدون کوکی نمایش داده می‌شود.
* نرخ‌محدودیت تأیید سفارش: پنج تلاش ناموفق در ۶۰۰ ثانیه برای هر سفارش+IP و سقف ۲۵ برای کل سفارش؛ تلاش ششم 429 با Retry-After. فقط خطاها شمرده می‌شوند و موفقیت شمارنده را پاک می‌کند.
* IP واقعی پشت Nginx→LiteSpeed با اعتماد به لوپ‌بک و هدر X-Forwarded-For؛ دو کلاینت مستقل دو باکت جدا دارند.
* فقط فیلد hsw_verify_email پذیرفته می‌شود؛ فیلد عمومی email دیگر این مسیر را فعال نمی‌کند.
* سفارش بدون ایمیل صورتحساب به‌جای فرم بی‌نتیجه، پیام «وارد حساب کاربری شوید» و لینک ورود نشان می‌دهد.
* نسخه 1.11.278؛ ساخت ZIP با پایان‌خط LF و قابل بازتولید؛ اصلاح شمارش ویجت‌ها (۶۳) و انتقال یادداشت‌های انتشار به docs/archive/release-notes/.

= 1.11.277 =
* امنیت و حریم خصوصی: کنترل دسترسی در /complete/ و order-received بر اساس استاندارد ووکامرس؛ سفارش مشتری ثبت‌نام‌شده برای بازدیدکنندهٔ مهمان نیازمند ورود یا تأیید ایمیل صورتحساب است و مشتریان دیگر مسدود می‌شوند.
* هوک‌های woocommerce_thankyou فقط پس از تأیید موفقیت‌آمیز دسترسی اجرا می‌شوند.
* تست‌های رگرسیون کامل برای مالک، مهمان با کلید، مشتری دیگر و لینک ایمیل پس از logout در tests/qa/order-auth-wp.php اضافه شد.

= 1.11.276 =
* تکمیل رفع باگ: هوک‌های تشکر (woocommerce_before_thankyou، woocommerce_thankyou_{method} و woocommerce_thankyou) حالا از یک گارد مشترک و بر اساس شمارهٔ سفارش اجرا می‌شوند؛ در یک درخواست، حتی وقتی کارت تکمیل سفارش و کارت پرداخت هر دو رندر شوند، هر هوک دقیقاً یک بار اجرا می‌شود و روی صفحهٔ بومی order-received ووکامرس دوباره اجرا نمی‌شود.
* رفع باگ: مسیر ذخیرهٔ تصویر تیکت با wp_upload_dir() ساخته می‌شود (سایت‌هایی که پوشهٔ uploads را جابه‌جا کرده‌اند)، تصاویر نسخه‌های قبل از wp-content/uploads خوانده می‌شوند، نام فایل با پیشوند تصادفی ذخیره می‌شود و هدر Content-Disposition امن شد.
* تست رگرسیون: tests/qa/ticket-image-wp.php و tests/qa/thankyou-hook-wp.php اضافه شدند و در GitHub Actions اجرا می‌شوند؛ tests/qa/ticket-image-browser-probe.js برای بررسی نقش‌ها با مرورگر واقعی روی سایت زنده است.
* اصلاح یادداشت‌های انتشار: مسیر قدیمی REST در یادداشت 1.11.273 و شمارش موارد در 1.11.274 به‌روز شد.

= 1.11.275 =
* نسخه نهایی (رفع باگ): تصویر تیکت 403 و هوک thankyou فیکس شد؛ نسخه پایدار برای نصب روی سایت مشتری.

= 1.11.274 =
* رفع باگ (بحرانی): تصویر تیکت برای هیچ کاربری نمایش داده نمی‌شد؛ سرویس تصویر از مسیر REST به admin-post.php منتقل شد تا صاحب تیکت و ادمین تصویر را ببینند و سایرین ۴۰۳ بگیرند؛ compares امضا با hash_equals.
* رفع باگ: هوک عمومی woocommerce_thankyou در صفحه‌ی /complete/ اجرا نمی‌شد؛ فقط woocommerce_thankyou_{method} اجرا می‌شد؛ حالا هوک عمومی دقیقاً یک بار برای هر سفارش اجرا می‌شود (گارد static).
* تمیزی کاراکترهای ناخواسته در Changelog؛ توضیح استمرت notes (claims ۱–۵ از ۷).

= 1.11.273 =
* نسخه آزمایشی (اصلاح امنیتی): گارد تکرار wp_die در ثبت دیدگاه AJAX؛ محدوده‌های اروانکلود در لیست proxyهای معتبر throttle OTP/IP؛ لیست مجاز (allowlist) برای درگاه‌های شارژ کیف پول؛ عکس‌های تیکت خارج از رسانه عمومی با لینک امضا شده؛ وب‌هوک ایمیل: رمز از هدر X-HSW-Inbound-Secret و مقایسه case-insensitive فرستنده.
* اصلاح خروجی CSV تیکت‌ها، آیکون‌های فرم آدرس، برگهٔ موبایل «کالا اضافه شد» و پاک‌سازی هنگام غیرفعال‌سازی و حذف افزونه.

= 1.11.272 =
* نسخه آزمایشی (اصلاح امنیتی): شارژ کیف پول دیگر با «پرداخت در محل» یا با خودِ کیف پول تسویه نمی‌شود؛ مرحلهٔ پرداخت همان سبدِ روی صفحه را به درگاه می‌فرستد و سفارش مشتری دیگر را نشان نمی‌دهد؛ شمارهٔ تایپ‌شده هنگام فعال‌سازی ورود دوعاملی تلگرام بدون تأیید تلگرام ثبت نمی‌شود. نیازمند آزمون staging با درگاه واقعی.
* اصلاح خروجی CSV تیکت‌ها، آیکون‌های فرم آدرس، برگهٔ موبایل «کالا اضافه شد» و پاک‌سازی هنگام غیرفعال‌سازی و حذف افزونه.

= 1.11.271 =
* نسخه آزمایشی: فهرست بررسی عکس‌های تیکت حذف‌شده؛ عکس‌ها خودکار حذف نمی‌شوند.

= 1.11.270 =
* نسخه آزمایشی: پاک‌سازی اعلان‌های قابل شناسایی تیکت هنگام حذف دائمی؛ عکس‌های پیوست همچنان باقی می‌مانند.

= 1.11.269 =
* نسخه آزمایشی: بزرگ‌نمایی تصویر تیکت در پیشخوان با امکان پیمایش و بازگشت به اندازه عادی.

= 1.11.268 =
* نسخه آزمایشی: نمایش عکس تیکت در پنجرهٔ پیش‌نمایش پیشخوان؛ پاک‌سازی خودکار فایل تیکت هنوز اضافه نشده است.

= 1.11.267 =
* نسخه آزمایشی: بازسازی پیشخوان تیکت و جلوگیری از پاسخ پشتیبانی به تیکت بسته تا زمان بازگشایی.

= 1.11.266 =
* نسخه آزمایشی: بهبود جداسازی تیکت‌ها، مدیریت خطای ثبت پاسخ و اطلاع‌رسانی خطای پیوست. پیوست‌ها همچنان خصوصی نیستند.

= 1.11.265 =
* نسخه آزمایشی: بهبود اشتراک‌گذاری، نشان‌کردن، اندازه قلم و فهرست سایدبار صفحه نوشته.

= 1.11.264 =
* نسخهٔ آزمایشی: بهبود فهرست، رنگ متن، فرم دیدگاه و نمایش قیمت در صفحهٔ نوشته و صفحه‌بندی آرشیو.

= 1.11.263 =
* نسخهٔ آزمایشی: اصلاح رنگ متن و آیکون دکمه مشاهده همه در لوپ پیشنهاد شگفت‌انگیز.

= 1.11.262 =
* نسخهٔ آزمایشی: یکپارچه‌سازی پنل استایل دکمه‌های لوپ و بخش جداگانه برای دکمهٔ بنر؛ نیازمند بازآزمایی Elementor روی staging.

= 1.11.261 =
* نسخهٔ آزمایشی: جلوگیری از ثبت تراکنش صفر هنگام ذخیرهٔ موجودی بدون تغییر؛ نیازمند بازآزمایی staging.

= 1.11.260 =
* نسخهٔ آزمایشی: به‌روزرسانی نمایش تخفیف در خلاصهٔ پرداخت پس از تغییر کوپن؛ نیازمند آزمون staging.

= 1.11.259 =
* نسخهٔ آزمایشی: بارگذاری نشست سبد پیش از اعمال یا حذف کوپن در پرداخت؛ نیازمند بازآزمایی staging.

= 1.11.258 =
* نسخهٔ آزمایشی: اصلاح عنوان مبلغ و وضعیت پرداخت هنگام دریافت در فاکتور مشتری؛ نیازمند بازآزمایی staging.

= 1.11.257 =
* نسخهٔ آزمایشی: حذف نشان «پرداخت شده» برای سفارش مبلغ‌دار با روش پرداخت هنگام دریافت؛ نیازمند بررسی روی staging.

= 1.11.256 =
* نسخهٔ آزمایشی: بهبود نمایش نام رنگ‌های فارسی در سبد محصولات متغیر؛ نیازمند بررسی روی staging و آزمون ثبت سفارش.

= 1.11.255 =
* نسخهٔ آزمایشی: محاسبهٔ مجدد سبد برای نمایش تازه‌تر هزینهٔ ارسال در ویجت‌ها؛ نیازمند آزمون روی محیط آزمایشی.

= 1.11.254 =
* Fix: اولین ذخیرهٔ کلید یا سقف ارسال رایگان (وقتی option هنوز ساخته نشده) هم کش نرخ ارسال را باطل می‌کند؛ قبلاً فقط `update_option` وصل بود و `add_option` نه.
* تست: `tests/qa/free-shipping-cache.php` با هشت بررسی، مسیر واقعی `update_option`/`delete_option` را اجرا می‌کند.

= 1.11.253 =
* Fix: با خاموش‌کردن کیف پول، مسیرهای REST شارژ/پرداخت/تبدیل امتیاز هم بسته می‌شوند (قبلاً فقط ثابت اضطراری چک می‌شد).
* Fix: پرچم `hsw_free_shipping` روی نرخ ارسال واقعاً ذخیره می‌شود؛ نوشتن روی `meta_data` بی‌اثر بود.
* Fix: خاموش‌کردن یا تغییر سقف ارسال رایگان، کش نرخ ارسال ووکامرس را برای همهٔ نشست‌ها بی‌اعتبار می‌کند.
* Fix: پنل کنترل ویجت‌ها توضیح می‌دهد «خاموش» یعنی حذف از فهرست المنتور، نه توقف بارگذاری فایل یا خاموشی بخش‌های ویجت جامع.

= 1.11.252 =
* Fix: رفع ۱.۱۱.۲۵۱ برای پاک‌سازی کش کار نمی‌کرد — `add_action` فقط یک آرگومان می‌داد و `$option` همیشه خالی بود. حالا با `update_option()` واقعی تست شد: تغییر REST صفر پاک‌سازی.
* Fix: دو صفحهٔ تنظیمات باقی‌مانده (امنیت و مدیریت ویجت) هنوز به slug خام POST می‌کردند؛ حالا هر پنج صفحه یک رفتار دارند.
* Fix: برچسب XML-RPC حالا «وضعیت فیلتر HamiShop» است، نه وضعیت نهایی همهٔ فیلترها.

= 1.11.251 =
* Fix: گارد REST کاربران با سیاست خودش یکی شد — ویرایشگر/نویسنده دیگر روی `/users/me` خطا نمی‌گیرند و مشتری فقط رکورد خودش را می‌بیند.
* Fix: فرم‌های تنظیمات فقط وقتی به آدرس سفارشی پیشخوان POST می‌کنند که گارد واقعاً فعال باشد؛ در حالت ثابت اضطراری یا نبودِ rewrite به `wp-admin` برمی‌گردند.
* Fix: تشخیص بلاک ووکامرس با `has_block('woocommerce/')` هرگز مطابقت نمی‌داد و استایل بلاک‌ها حذف می‌شد؛ حالا فضای‌نام بلاک بررسی می‌شود.
* Fix: هشدار تعارض درگاه دیگر برای دامنه‌ای که در allowlist است نمایش داده نمی‌شود.
* Fix: تغییر تنظیمات غیرظاهری امنیت دیگر کل کش سایت را پاک نمی‌کند.
* Fix: `?author=1` حالا قالب ۴۰۴ را نشان می‌دهد، نه آرشیو نویسنده با کد ۴۰۴.
* Fix: متن XML-RPC وضعیت واقعی فیلتر را نشان می‌دهد و متن صفحهٔ ورود دربارهٔ فونت درست شد.

= 1.11.250 =
* Fix: قانون `.hsw-c .hsw-csummary__cta:hover` (specificity بیشتر) رنگ hover پالت را دوباره بر رنگ انتخابی ویجت غالب می‌کرد؛ حالا همان زنجیرهٔ متغیرها را دارد.
* Fix: حالت `:active` دکمهٔ سبد و نوار پایین و CTA تسویه هم از رنگ انتخابی مشتق می‌شود.
* Fix: دکمهٔ موبایل سبد پایهٔ خود را از `--hswc-cta` می‌خواند و کنترل رنگش هیچ اثری نداشت.

= 1.11.249 =
* Fix: ذخیرهٔ پالت با فونت معتبر دیگر خطای «رنگ معتبر نبود» نمی‌دهد (حلقه فقط روی نقش‌های رنگی می‌گردد).
* Fix: `contrast_text()` رنگ واقعیِ بازگشتی را می‌سنجد؛ `#777777` حالا `#000000` با ۴٫۶۹:۱ می‌گیرد، نه `#111827` با ۳٫۹۶:۱.
* Fix: حالت‌های «فونت طرح» و «ارث‌بری» دیگر به قانون عمومی فونت پالت نمی‌بازند (بلوک بعد از آن منتقل شد)؛ Typography المنتور همچنان مقدم است.
* Fix: متن دکمهٔ خرید در hover از رنگ متن پالت پیروی می‌کند، نه `#fff` سخت‌کد.
* Fix: CTA سبد و تسویه در hover رنگ انتخابی خودشان را نگه می‌دارند و به رنگ hover پالت نمی‌پرند.

= 1.11.248 =
* Fix: رنگ عنوان هدر حساب کاربری دیگر با `!important` قفل نشده — کنترل «رنگ متن» المنتور اثر می‌گذارد و پیش‌فرض سفید می‌ماند.
* Fix: کنترل پس‌زمینهٔ هدر حساب حالا گرادیان را جایگزین می‌کند؛ قبلاً رنگ پشت گرادیان پنهان بود و هیچ اثری نداشت.
* Fix: حالت‌های «فونت طرح» و «ارث‌بری» دیگر روی فرزندان `!important` نمی‌گذارند؛ Typography صریح المنتور مقدم است.
* Fix: `readable_on()` روی پس‌زمینهٔ تیره به سمت سفید می‌رود (قبلاً متن را تیره‌تر می‌کرد تا محو شود) و `contrast_text()` بیشترین کنتراست را انتخاب می‌کند، نه آستانهٔ ۳:۱.
* Fix: رنگ نامعتبر در پالت دیگر بی‌صدا به پیش‌فرض برنمی‌گردد؛ مقدار قبلی حفظ و فیلدهای ردشده نام‌برده می‌شوند.
* Fix: نام فونت دستی قبل از چاپ در `<style>` پاک‌سازی می‌شود (نقل‌قول و آکولاد حذف).

= 1.11.247 =
* Fix: اگر ذخیرهٔ روش ارسال خطا بدهد، دکمهٔ «ادامه» دیگر رد نمی‌شود — روی همان صفحه می‌ماند و پیام خطا نمایش داده می‌شود (قبلاً با نرخ قبلی ادامه می‌داد).
* Fix: الزام قوانین یک سیاست واحد دارد؛ لینک سفارشی فقط نمایش است و الزام از تنظیمات فروشگاه یا فیلتر `hsw_terms_required` می‌آید.
* Fix: صفحهٔ بی‌ربطی که در تنظیمات مسیر خرید انتخاب شده بود، از طریق `wp_robots` noindex می‌گرفت در حالی که متای سئوی آن دست‌نخورده بود.
* Fix: مارکر قدیمی بدون محتوا دیگر صفحه را وصل نمی‌کند؛ و صفحهٔ درست با slug متفاوت حالا خودکار پیدا می‌شود.

= 1.11.246 =
* New: «رفتار خرید» در ویجت جعبه خرید — دو حالت. «استپر» همان رفتار فعلی است (استپر بعد از افزودن ظاهر می‌شود و سبد را به‌روز می‌کند). «کنار دکمهٔ خرید» استپر را همیشه کنار «خرید آنلاین» می‌گذارد و هیچ درخواستی به سرور نمی‌فرستد؛ تعداد انتخابی فقط با زدن دکمهٔ خرید به سبد اضافه می‌شود.
* New: در حالت کنار دکمه، استپر از ۱ شروع می‌شود (معنی «چند تا اضافه کنم»)، سبد خرید آیکون حذف ندارد، و در تعداد ۱ دکمهٔ منفی سر جایش می‌ماند و فقط کلیک را رد می‌کند.

= 1.11.245 =
* New: «راه‌اندازی مسیر خرید» در پنل «کنترل ویجت‌ها» — وضعیت واقعی صفحهٔ پرداخت و صفحهٔ تکمیل خرید را نشان می‌دهد و با یک دکمه، فقط صفحه‌هایی را می‌سازد که وجود ندارند.
* New: صفحه‌ای که از قبل وجود دارد فقط «وصل» می‌شود، نه بازسازی؛ و صفحه‌ای که نشانی /payment/ یا /complete/ را در اختیار دارد ولی مال حامیشاپ نیست، هرگز دست نمی‌خورد (صفحه با نشانی /hamishop-payment/ ساخته می‌شود).
* New: شورت‌کدهای `[hamishop_payment]` و `[hamishop_complete]` — صفحه در هر قالبی رندر می‌شود و با ذخیرهٔ مجدد المنتور از بین نمی‌رود.
* New: هر دو صفحهٔ مسیر خرید `noindex, nofollow` می‌شوند، مثل صفحهٔ سبد و تسویهٔ خود ووکامرس.
* Fix: صفحهٔ سبد پس از لغو پرداخت در درگاه خراب می‌شد — سبد خالی بود ولی سفارش در انتظار در نشست مانده بود، صفحه گرید «خالی» را انتخاب می‌کرد و ویجت اقلام ردیف سفارش را داخلش می‌کشید (بدون جمع کل، کوپن و دکمه). ویجت‌های سبد دیگر هرگز سفارش را به‌جای سبد رندر نمی‌کنند؛ مرحلهٔ پرداخت دست‌نخورده است.
* Fix: وعدهٔ ارسال رایگان با خاموش‌بودن کلید حذف شد — بنر سبد و راهنمای خلاصه تسویه حالا `promise_threshold()` را می‌خوانند که بدون کلید، صفر برمی‌گرداند.
* Fix: هزینهٔ صفر ارسال دیگر «رایگان» تفسیر نمی‌شود. پنج حالت صریح (رایگان / هزینه‌دار / در انتظار / نیازی نیست / در دسترس نیست) و یک منبع واحد در `shipping_state()`؛ مقصد بدون نرخ حالا «روش ارسال در دسترس نیست» می‌گوید.
* Fix: متن پیش‌فرض «رایگان (خرید بالای ۵۰۰ هزار)» و «… ۵۰۰ تومان» حذف شد و ویجت‌های ذخیره‌شده با همان متن، «رایگان» نشان می‌دهند.
* Fix: نبودن چک‌باکس قوانین دیگر «پذیرش» حساب نمی‌شود؛ الزام از تنظیمات خود فروشگاه پیروی می‌کند و کنترل غایب، خطای پیکربندی است.
* Fix: خطای ذخیرهٔ روش ارسال بی‌صدا نادیده گرفته نمی‌شود — انتخاب به حالت تأییدشده برمی‌گردد و پیام نشان داده می‌شود.
* Fix: ردیف «کسر از موجودی کیف پول» و کلید بی‌اثر آن حذف شد؛ کارت کیف پول می‌ماند ولی دیگر کسری وعده نمی‌دهد.
* Fix: `hsw_pay_page_id` هنگام حذف افزونه پاک نمی‌شد.

= 1.11.244 =
* New: «هدر GC» — a third header widget. A rounded bar floats over the page and docks into a full-width blurred bar on scroll; the brand mark is a «G» drawn as a circuit trace that draws itself; a gradient underline follows the pointer; dropdown panels stagger their rows in. The mark, brand text, every menu row, six panel slots (icon + title + description + footer), the cart badge, the account button and the mobile drawer are all controls.
* New: «رفتار با اسکرول» — سه حالت: چسبان (پیش‌فرض)، پنهان‌شدن با اسکرول پایین و بازگشت فوری با اسکرول بالا، یا درون جریان صفحه.
* New: نشان برند به‌صورت خودکار همان لوگوی سایت است؛ لازم نیست دوباره آپلود شود. نشان مدار GC گزینه و جایگزین است.
* Changed: پنل‌های هدر GC حالا چهار فهرست جدا هستند («پنل ۱» تا «پنل ۴») — هر ردیف همان‌جایی است که دیده می‌شود، بدون همگام نگه‌داشتن شمارهٔ پنل در دو فهرست.
* Changed: دکمهٔ علاقه‌مندی از آیتم‌های سبد خرید حذف شد؛ کاری انجام نمی‌داد و در سبد خرید معنا ندارد.
* New: کلید «نمایش عنوان بالای کارت» در زمان‌بندی تحویل، و متن پیش‌فرض «روز انتخاب تحویل به پست».
* Fix: متن دکمهٔ «ادامه و پرداخت» در تسویه حساب سیاه روی زمینهٔ سرمه‌ای بود (کنتراست ۱٫۱:۱). قاعدهٔ `.hsw-k a { color: inherit }` با specificity (0,1,1) از رنگ خودِ دکمه (0,1,0) قوی‌تر بود؛ حالا `:where()` شده و دکمه رنگ پالت را می‌گیرد (۹٫۱:۱).
* Fix: کلید عنوان زمان‌بندی خاموش نمی‌شد — `opt()` رشتهٔ خالی را «تنظیم‌نشده» می‌گیرد و پیش‌فرض را برمی‌گرداند، که همان مقدار حالت خاموش سوئیچ است.
* Fix: «هدر GC» never reached the Elementor panel — the file was required by `register_widgets()` but missing from the class list that follows it, and that list skips unknown names silently. A new check now fails the build when a widget class is not in it.
* Fix: the blog page widget threw `Call to undefined method HSW_Widget_Blog_Page::is_demo()`; the method existed on the archive, cart and product bases but not on the blog base, so the description box never rendered. The blog grid threw the same way over `HSW_Composite::is_active()`, which was never written — it now uses `is_composite_part()`.
* Fix: the harness now audits method resolution (`$this->x()` and `HSW_*::x()`), so an undefined method fails the build instead of surfacing as an admin banner on a customer's site.
* Fix: the drawer's dark button was dark-on-dark (`#172b25` on `#06271f`); `.hsw-gc a { color: inherit }` outranked the button rule. Every anchor colour rule now carries the `.hsw-gc` prefix — measured white on `#06271f` after.
* Fix: a long store name pushed the page 172px sideways at 320px and 102px at 390px (`flex-shrink: 0` on the brand). It now truncates with an ellipsis — overflow measured 0 at 320/360/390/414/768/1024/1100/1280/1440.

= 1.11.243 =
* Fix: The article page scrolled sideways on a phone (+52px at 390px). The prev/next grid used `1fr`, which cannot shrink below its content, so a long neighbouring title pushed the column to 492px inside a 342px box. Now `minmax(0, 1fr)` plus `min-width: 0` on the item — measured at 320/360/390/768/1024/1280.
* Fix: The 62px bottom padding that clears the fixed dock was unconditional, so a widget with the dock switched off still had dead space on mobile. It is scoped to `hsw-pp--dock`, which is only printed when the dock renders.
* Fix: With no product in the article, the dock's «ثبت دیدگاه» button still linked to `#hsw-comments` even when that section was not printed. Same guard as the «نظر» button.

= 1.11.242 =
* Fix (security): The post widget rendered a draft or private post when its numeric «شناسه نوشته» field pointed at one, and a password-protected post rendered in full because the body bypassed `get_the_content()`. Non-published posts now require `edit_post` capability, and `post_password_required()` prints WordPress's own password form instead.
* Fix: On a single post, «مجله», «بازگشت به مجله», «مشاهده همه» and the breadcrumb category all linked back to the article being read — `blog_base_url()` took the current request path as the base. It uses the posts page there now, and the category link goes to the real category archive.
* Fix: Turning «فهرست مطالب» off hid the in-article list but not the sidebar one. Both follow the option now.
* Fix: The mobile dock's «نظر» button linked to `#hsw-comments` even when that section was not printed. It is only a link when the anchor exists.
* Fix: The sidebar heading said «پربازدیدترین مقالات» while the query sorts by comment count. Renamed to «پربحث‌ترین مقالات».

= 1.11.241 =
* Fix: The account panel, the blog post panel and the product sheet hard-coded the bundled Vazirmatn instead of reading `--hsw-font`, so on a shop whose palette font is something else those three screens rendered in a different face from the rest of the site. They use the palette font now, like every other stylesheet.
* No change when the palette font is the default: measured in Chrome, `.hsw-ac` computes to the same font before and after. With the palette set to another family, all three follow it.
* The `!important` on the product sheet is untouched — only the family now comes from the palette.

= 1.11.240 =
* Fix: «فونت پایه ویجت» was offered on every widget's Style tab but only four widgets applied it — on account, cart, checkout, header, archive, product, blog and footer it did nothing. The class now goes on the Elementor wrapper through `elementor/frontend/widget/before_render`. `palette` (the default) adds no class, so pages that never touched the control render byte-identical HTML (verified by diffing home, shop and account before/after).
* New: `add_filter( 'hsw_disable_elementor_google_fonts', '__return_false' );` keeps Elementor's Google Fonts on archive and account pages. The suppression is unchanged by default.
* Docs: the `preload_font()` comment claimed the font is only preloaded on pages that use it. It is preloaded on every front-end page, because `hsw-fonts` is registered on every request and no widget has rendered yet at `wp_head`. Comment corrected; behaviour untouched.

= 1.11.239 =
* Fix: The ticket CSV counted only approved replies, while `get_comments()` — used by the ticket list — defaults to `status => all`, which WordPress turns into `comment_approved = '0' OR comment_approved = '1'`. A ticket with a reply waiting for moderation therefore showed a lower number in the CSV than in the admin list. The query now matches `IN ('0', '1')`; spam and trash are excluded by both.
* Verified against a ticket holding one approved, one pending, one spam and one trash reply: `get_comments()` = 4, `reply_counts()` = 4.
* Two checks in `tools/ci-checks.php` fail if the approved-only filter comes back.

== Upgrade Notice ==

= 1.11.222 =
نسخهٔ ۱.۱۱.۲۲۱ را نصب نکنید: مسیر آپدیت قدیمی را دارد و می‌تواند چند دقیقه سایت را ۵۰۳ کند. مستقیم ۱.۱۱.۲۲۲ یا بالاتر بروید.
