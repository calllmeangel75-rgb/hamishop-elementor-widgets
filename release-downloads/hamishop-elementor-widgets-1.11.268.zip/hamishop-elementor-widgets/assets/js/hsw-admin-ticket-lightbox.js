/* Ticket editor only. Native dialog keeps focus and supports Escape. */
(function () {
	'use strict';
	if (!document.body.classList.contains('post-type-hsw_ticket')) { return; }
	var dialog = document.createElement('dialog');
	if (typeof dialog.showModal !== 'function') { return; } // Keep ordinary link fallback.
	dialog.className = 'hsw-ticket-lightbox';
	dialog.setAttribute('aria-label', 'تصویر پیوست تیکت');
	var close = document.createElement('button');
	close.type = 'button';
	close.className = 'hsw-ticket-lightbox__close';
	close.setAttribute('aria-label', 'بستن تصویر');
	close.textContent = '×';
	var image = document.createElement('img');
	image.alt = 'تصویر پیوست تیکت';
	dialog.appendChild(close);
	dialog.appendChild(image);
	document.body.appendChild(dialog);
	var trigger = null;
	close.addEventListener('click', function () { dialog.close(); });
	dialog.addEventListener('click', function (event) {
		if (event.target === dialog) { dialog.close(); }
	});
	dialog.addEventListener('close', function () {
		image.removeAttribute('src');
		if (trigger && trigger.isConnected) { trigger.focus(); }
		trigger = null;
	});
	document.addEventListener('click', function (event) {
		var link = event.target.closest('.hsw-ticket-attach');
		if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) { return; }
		trigger = link;
		image.src = link.href;
		try {
			dialog.showModal();
			event.preventDefault();
			close.focus();
		} catch (error) {
			trigger = null; // Let the browser open the original link.
		}
	});
}());
