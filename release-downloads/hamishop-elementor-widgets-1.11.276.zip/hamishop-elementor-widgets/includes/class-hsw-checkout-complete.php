<?php
/**
 * Checkout REST route: final order placement for the design's own pay button.
 *
 *  - POST /hsw/v1/checkout/complete : creates the order through WooCommerce's
 *    own API (WC_Checkout::create_order) using the session customer address,
 *    the chosen shipping method / payment gateway, coupons and the order note
 *    stored by the other checkout routes — then hands the customer over to
 *    $gateway->process_payment() and returns the redirect URL (the gateway's
 *    own page or WooCommerce's order-received page).
 *
 * This is the bridge that makes the Elementor pay page a real final step:
 * without it the design's CTA could only redirect back to checkout because
 * the page hosts no native `form.checkout`.
 *
 * @package HamiShop_Elementor_Widgets
 */

defined( 'ABSPATH' ) || exit;

class HSW_Checkout_Complete {

	const NS = 'hsw/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'route' ) );
	}

	public function route() {
		register_rest_route(
			self::NS,
			'/checkout/complete',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'complete' ),
				'permission_callback' => array( $this, 'can_checkout' ),
				'args'                => array(
					'method'        => array( 'sanitize_callback' => 'sanitize_text_field' ),
					'schedule_day'  => array( 'sanitize_callback' => 'sanitize_text_field' ),
					'schedule_slot' => array( 'sanitize_callback' => 'sanitize_text_field' ),
					'terms'         => array( 'sanitize_callback' => 'rest_sanitize_boolean' ),
				),
			)
		);
	}

	/**
	 * Any visitor with a valid wp_rest nonce and a cart session.
	 */
	public function can_checkout( $request ) {
		if ( class_exists( 'HSW_Checkout_Rest' ) ) {
			HSW_Checkout_Rest::ensure_cart();
		}
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new WP_Error( 'hsw_rest_nonce', __( 'نشست منقضی شده؛ صفحه را دوباره بارگذاری کنید.', 'hamishop-elementor-widgets' ), array( 'status' => 403 ) );
		}
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return new WP_Error( 'hsw_no_cart', __( 'سبد خرید یافت نشد.', 'hamishop-elementor-widgets' ), array( 'status' => 400 ) );
		}
		if ( ! WC()->session ) {
			return new WP_Error( 'hsw_no_session', __( 'نشست یافت نشد.', 'hamishop-elementor-widgets' ), array( 'status' => 400 ) );
		}
		return true;
	}

	/**
	 * Two counters: a strict one per IP+session and a 5x looser one per IP only.
	 *
	 * Iranian mobile users often share one carrier NAT address, so an IP-only
	 * limit as strict as the session one would block real customers. Thresholds
	 * are filterable through `hsw_checkout_rate_limit`.
	 *
	 * @param string $bucket  Route name.
	 * @param int    $limit   Requests per window.
	 * @param int    $window  Window in seconds.
	 * @return true|WP_Error
	 */
	protected function rate_gate( $bucket, $limit, $window ) {
		if ( ! class_exists( 'HSW_Throttle' ) ) {
			return true;
		}

		/**
		 * Filter the checkout rate limit.
		 *
		 * @param array  $limit  [ 'limit' => int, 'window' => int, 'ip_multiplier' => int ].
		 * @param string $bucket Route name.
		 */
		$conf = apply_filters(
			'hsw_checkout_rate_limit',
			array(
				'limit'         => (int) $limit,
				'window'        => (int) $window,
				'ip_multiplier' => 5,
			),
			$bucket
		);

		$ip   = HSW_Throttle::ip();
		$sid  = ( WC()->session ) ? (string) WC()->session->get_customer_id() : '';
		$conf = wp_parse_args( $conf, array( 'limit' => 20, 'window' => 60, 'ip_multiplier' => 5 ) );

		$retry = 0;

		if ( '' !== $sid ) {
			$hit = HSW_Throttle::hit( 'hsw-ck-' . $bucket . '-' . md5( $ip . '|' . $sid ), $conf['limit'], $conf['window'] );
			if ( ! $hit['allowed'] ) {
				$retry = (int) $hit['retry_after'];
			}
		}

		/* IP-only counter, generous enough for CGNAT. */
		$hit_ip = HSW_Throttle::hit( 'hsw-ck-ip-' . $bucket . '-' . md5( $ip ), (int) $conf['limit'] * max( 1, (int) $conf['ip_multiplier'] ), $conf['window'] );
		if ( ! $hit_ip['allowed'] ) {
			$retry = max( $retry, (int) $hit_ip['retry_after'] );
		}

		if ( $retry > 0 ) {
			$error = new WP_Error(
				'hsw_rate_limited',
				__( 'درخواست‌های زیادی ثبت شده است؛ چند لحظه صبر کنید و دوباره تلاش کنید.', 'hamishop-elementor-widgets' ),
				array( 'status' => 429 )
			);
			$error->add_data( array( 'retry_after' => $retry ) );

			return $error;
		}

		return true;
	}

	/**
	 * Place the order and start the payment hand-off.
	 */
	public function complete( $request ) {
		$gate = $this->rate_gate( 'complete', 20, 60 );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		/*
		 * An order can already exist and still need payment: a wallet top-up (the
		 * order is created by the wallet endpoint, there is no cart at all) and a
		 * retried payment from «سفارش‌های من» both land on the pay page with the
		 * order only in `order_awaiting_payment`. The old flow created a NEW order
		 * from the cart here, so the pay button answered «سبد خرید خالی است» and a
		 * 150,000 top-up could never be paid.
		 */
		$awaiting = $this->awaiting_order();
		if ( $awaiting ) {
			return $this->pay_awaiting_order( $awaiting, $request );
		}

		if ( WC()->cart->is_empty() ) {
			return new WP_Error( 'hsw_empty_cart', __( 'سبد خرید خالی است؛ ابتدا محصولی به سبد اضافه کنید.', 'hamishop-elementor-widgets' ), array( 'status' => 400 ) );
		}

		WC()->cart->calculate_totals();
		$this->maybe_default_shipping();
		$this->store_schedule_from_request( $request );

		$data = $this->order_data( $request );

		/* The pay page's own terms checkbox must be accepted server-side too —
		 * but only when the shop has terms to accept. Demanding a tick for a
		 * document that does not exist is not consent, it is a dead end. */
		if ( HSW_Complete_Route::terms_required() && empty( $data['terms'] ) ) {
			return new WP_Error(
				'hsw_terms',
				__( 'برای ثبت سفارش باید قوانین و شرایط فروشگاه را بپذیرید.', 'hamishop-elementor-widgets' ),
				array( 'status' => 400 )
			);
		}

		/* The design takes the delivery address from the customer account;
		 * guests (and accounts without any address) get a friendly pointer. */
		if ( '' === trim( $data['billing_first_name'] . $data['billing_last_name'] . $data['billing_address_1'] ) ) {
			$logged = is_user_logged_in();
			return new WP_Error(
				'hsw_no_address',
				$logged
					? __( 'آدرسی برای تحویل ثبت نشده است؛ ابتدا در حساب کاربری آدرس را کامل کنید.', 'hamishop-elementor-widgets' )
					: __( 'برای ثبت سفارش، وارد حساب کاربری شوید و آدرس تحویل را ذخیره کنید.', 'hamishop-elementor-widgets' ),
				array(
					'status'   => 400,
					'hsw_link' => array(
						'url'   => $logged ? wc_get_account_endpoint_url( 'edit-address' ) : wc_get_page_permalink( 'myaccount' ),
						'label' => $logged ? __( 'تکمیل آدرس در حساب کاربری', 'hamishop-elementor-widgets' ) : __( 'ورود / ثبت‌نام', 'hamishop-elementor-widgets' ),
					),
				)
			);
		}

		/*
		 * Half an address is not an address. Name the missing fields and hand
		 * the customer a link back to the form instead of letting WooCommerce
		 * answer «مقدار ... را کامل کنید» with no way out of the pay page.
		 */
		$missing = HSW_Checkout_Rest::missing_address_fields( WC()->customer );
		if ( $missing ) {
			return new WP_Error(
				'hsw_incomplete_address',
				sprintf(
					/* translators: %s: comma separated field labels. */
					__( 'نشانی تحویل کامل نیست؛ این موارد را تکمیل کنید: %s', 'hamishop-elementor-widgets' ),
					implode( '، ', array_values( $missing ) )
				),
				array(
					'status'   => 400,
					'hsw_link' => array(
						'url'   => wc_get_checkout_url(),
						'label' => __( 'تکمیل نشانی تحویل', 'hamishop-elementor-widgets' ),
					),
				)
			);
		}

		$errors = $this->validate( $data );
		if ( $errors ) {
			return new WP_Error( 'hsw_checkout_validation', implode( ' ', array_slice( $errors, 0, 3 ) ), array( 'status' => 400 ) );
		}

		/*
		 * Captcha / anti-fraud / validation plugins hook these two. Our endpoint
		 * called create_order() directly, so none of them ever ran and an order
		 * could be placed with a failing captcha.
		 */
		do_action( 'woocommerce_before_checkout_process' );
		do_action( 'woocommerce_checkout_process' );

		$hooked = wc_get_notices( 'error' );
		if ( $hooked ) {
			$messages = array();
			foreach ( $hooked as $notice ) {
				$messages[] = wp_strip_all_tags( (string) ( $notice['notice'] ?? '' ) );
			}
			wc_clear_notices();
			return new WP_Error( 'hsw_checkout_process', implode( ' ', array_slice( array_filter( $messages ), 0, 3 ) ), array( 'status' => 400 ) );
		}

		try {
			$order_id = $this->create_order_locked( $data );
		} catch ( Throwable $e ) {
			return new WP_Error( 'hsw_order_failed', wp_strip_all_tags( $e->getMessage() ), array( 'status' => 500 ) );
		}
		if ( is_wp_error( $order_id ) ) {
			return new WP_Error( 'hsw_order_failed', wp_strip_all_tags( $order_id->get_error_message() ), array( 'status' => 500 ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new WP_Error( 'hsw_order_failed', __( 'ثبت سفارش انجام نشد؛ دوباره تلاش کنید.', 'hamishop-elementor-widgets' ), array( 'status' => 500 ) );
		}

		$this->decorate_order( $order );
		$this->persist_customer_address( $order, $data );

		/** Same hook WooCommerce fires in process_checkout() (emails, plugins). */
		do_action( 'woocommerce_checkout_order_processed', $order_id, $data, $order );

		if ( $order->needs_payment() ) {
			$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->get_available_payment_gateways() : array();
			$method   = (string) $data['payment_method'];
			if ( ! isset( $gateways[ $method ] ) ) {
				return new WP_Error( 'hsw_bad_gateway', __( 'روش پرداخت انتخاب‌شده در دسترس نیست؛ روش دیگری را انتخاب کنید.', 'hamishop-elementor-widgets' ), array( 'status' => 400 ) );
			}

			/* Mirror WC_Checkout::process_order_payment(). */
			WC()->session->set( 'order_awaiting_payment', $order_id );
			WC()->session->save_data();

			try {
				$result = $gateways[ $method ]->process_payment( $order_id );
			} catch ( Throwable $e ) {
				$result = array( 'result' => 'failure', 'messages' => wp_strip_all_tags( $e->getMessage() ) );
			}

			if ( ! is_array( $result ) || empty( $result['result'] ) || 'success' !== $result['result'] ) {
				$msg = '';
				if ( is_array( $result ) && ! empty( $result['messages'] ) ) {
					$msg = wp_strip_all_tags( is_array( $result['messages'] ) ? implode( ' ', $result['messages'] ) : (string) $result['messages'] );
				}
				return new WP_Error(
					'hsw_pay_failed',
					'' !== trim( $msg ) ? $msg : __( 'پرداخت انجام نشد؛ دوباره تلاش کنید یا روش پرداخت دیگری انتخاب کنید.', 'hamishop-elementor-widgets' ),
					array( 'status' => 402 )
				);
			}

			$result   = apply_filters( 'woocommerce_payment_successful_result', $result, $order_id );
			$redirect = ! empty( $result['redirect'] ) ? (string) $result['redirect'] : $order->get_checkout_order_received_url();

			/*
			 * Most gateways empty the cart inside process_payment(), but not all
			 * of them (and an offline gateway that forgets would let a refresh
			 * place a second order for the same items). Clearing it here makes
			 * the "one cart, one order" rule independent of the gateway.
			 */
			if ( WC()->cart && ! WC()->cart->is_empty() ) {
				WC()->cart->empty_cart();
			}
			if ( WC()->session ) {
				WC()->session->set( 'order_awaiting_payment', null );
			}
		} else {
			$order->payment_complete();
			wc_empty_cart();
			$redirect = apply_filters( 'woocommerce_checkout_no_payment_needed_redirect', $order->get_checkout_order_received_url(), $order );
		}

		/* The delivery slot belongs to this order only; start the next one clean. */
		if ( WC()->session ) {
			WC()->session->set( 'hsw_delivery_schedule', array() );
		}

		return rest_ensure_response(
			array(
				'ok'       => true,
				'result'   => 'success',
				'order_id' => (int) $order_id,
				'redirect' => $redirect,
			)
		);
	}

	/* =========================================================================
	 *  INTERNALS
	 * ====================================================================== */

	/**
	 * The order the customer is paying, when it is not built from the cart.
	 *
	 * Ownership is checked: the session id is not trusted on its own, because a
	 * shared browser or a copied cookie must never let someone pay (or read) an
	 * order that belongs to another account.
	 *
	 * @return WC_Order|null
	 */
	protected function awaiting_order() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return null;
		}

		$id = absint( WC()->session->get( 'order_awaiting_payment' ) );
		if ( ! $id ) {
			return null;
		}

		$order = wc_get_order( $id );
		if ( ! $order instanceof WC_Order || ! $order->needs_payment() ) {
			return null;
		}

		$owner = (int) $order->get_customer_id();
		if ( $owner && get_current_user_id() !== $owner ) {
			return null;
		}

		/*
		 * With products in the cart, the cart is what the pay page shows and
		 * what the customer agreed to pay. The session id can be much older
		 * than that cart: an abandoned wallet top-up, or a retried payment the
		 * customer walked away from. Paying it here sent the customer to the
		 * gateway for THAT order's amount — a 500,000 top-up instead of the
		 * 230,000 basket on the screen — and the basket never became an order.
		 *
		 * The awaiting order is only resumed when it was built from this very
		 * cart (same contents, same total — WooCommerce's own cart hash, the
		 * rule `WC_Checkout::create_order()` uses). Otherwise the normal path
		 * below creates the order the customer is looking at.
		 */
		if ( WC()->cart && ! WC()->cart->is_empty() ) {
			WC()->cart->calculate_totals();
			if ( ! $order->has_cart_hash( (string) WC()->cart->get_cart_hash() ) ) {
				return null;
			}
		}

		return $order;
	}

	/**
	 * Send an existing order to the gateway instead of creating a new one.
	 *
	 * @param WC_Order        $order   Order awaiting payment.
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	protected function pay_awaiting_order( $order, $request ) {
		if ( HSW_Complete_Route::terms_required() && ! rest_sanitize_boolean( $request->get_param( 'terms' ) ) ) {
			return new WP_Error(
				'hsw_terms',
				__( 'برای ثبت سفارش باید قوانین و شرایط فروشگاه را بپذیرید.', 'hamishop-elementor-widgets' ),
				array( 'status' => 400 )
			);
		}

		$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->get_available_payment_gateways() : array();
		$method   = sanitize_text_field( (string) $request->get_param( 'method' ) );
		if ( '' === $method ) {
			$method = (string) $order->get_payment_method();
		}

		if ( ! isset( $gateways[ $method ] ) ) {
			return new WP_Error( 'hsw_bad_gateway', __( 'روش پرداخت انتخاب‌شده در دسترس نیست؛ روش دیگری را انتخاب کنید.', 'hamishop-elementor-widgets' ), array( 'status' => 400 ) );
		}

		/*
		 * A wallet top-up may only be paid with a gateway that confirms the
		 * money. The gateway list is already filtered for the pay step; this
		 * keeps a hand-written request (`method=cod`) from walking past it.
		 */
		if ( class_exists( 'HSW_Wallet_Topup' ) && HSW_Wallet_Topup::is_topup_order( $order ) && ! HSW_Wallet_Topup::gateway_allowed( $method ) ) {
			return new WP_Error( 'hsw_bad_gateway', __( 'روش پرداخت انتخاب‌شده در دسترس نیست؛ روش دیگری را انتخاب کنید.', 'hamishop-elementor-widgets' ), array( 'status' => 400 ) );
		}

		if ( $method !== (string) $order->get_payment_method() ) {
			$order->set_payment_method( $gateways[ $method ] );
			$order->save();
		}

		try {
			$result = $gateways[ $method ]->process_payment( $order->get_id() );
		} catch ( Throwable $e ) {
			$result = array( 'result' => 'failure', 'messages' => wp_strip_all_tags( $e->getMessage() ) );
		}

		if ( ! is_array( $result ) || empty( $result['result'] ) || 'success' !== $result['result'] ) {
			$msg = '';
			if ( is_array( $result ) && ! empty( $result['messages'] ) ) {
				$msg = wp_strip_all_tags( is_array( $result['messages'] ) ? implode( ' ', $result['messages'] ) : (string) $result['messages'] );
			}
			return new WP_Error(
				'hsw_pay_failed',
				'' !== trim( $msg ) ? $msg : __( 'پرداخت انجام نشد؛ دوباره تلاش کنید یا روش پرداخت دیگری انتخاب کنید.', 'hamishop-elementor-widgets' ),
				array( 'status' => 402 )
			);
		}

		$result   = apply_filters( 'woocommerce_payment_successful_result', $result, $order->get_id() );
		$redirect = ! empty( $result['redirect'] ) ? (string) $result['redirect'] : $order->get_checkout_order_received_url();

		/* One order, one payment: nothing may be paid twice from this session. */
		WC()->session->set( 'order_awaiting_payment', null );

		return rest_ensure_response(
			array(
				'ok'       => true,
				'result'   => 'success',
				'order_id' => (int) $order->get_id(),
				'redirect' => $redirect,
			)
		);
	}

	/**
	 * Place the order behind an atomic one-shot lock.
	 *
	 * A double click (or a retrying client) used to reach `create_order()`
	 * twice before the cart was emptied: two pending orders for one cart.
	 * The throttle table's upsert is a single atomic statement, so of two
	 * parallel requests exactly one gets through and the rest are answered
	 * with a "your order is being placed" error. The lock lives 20 seconds —
	 * long enough to cover `create_order()` plus the gateway hand-off, short
	 * enough that a real failure can be retried moments later.
	 *
	 * @param array $data Checkout data for WC_Checkout::create_order().
	 * @return int|WP_Error Order id.
	 */
	protected function create_order_locked( $data ) {
		$sid = ( WC()->session ) ? (string) WC()->session->get_customer_id() : '';
		$key = 'hsw-ck-place-' . md5( HSW_Throttle::ip() . '|' . $sid );

		$lock = HSW_Throttle::hit( $key, 1, 20 );
		if ( ! $lock['allowed'] ) {
			return new WP_Error(
				'hsw_order_busy',
				__( 'سفارش شما در حال ثبت است؛ چند ثانیه صبر کنید و صفحه را دوباره بارگذاری نکنید.', 'hamishop-elementor-widgets' ),
				array( 'status' => 409 )
			);
		}

		return WC()->checkout()->create_order( $data );
	}

	/**
	 * Write the order address back to the customer.
	 *
	 * `WC_Checkout::create_order()` stores the address on the order only, so a
	 * customer who typed it during checkout opened the address book afterwards
	 * and read "no address saved". Copying the non-empty fields onto
	 * WC_Customer makes the next order (and the account page) use them.
	 *
	 * @param WC_Order $order Order.
	 * @param array    $data  Posted data used to create it.
	 */
	protected function persist_customer_address( $order, $data ) {
		if ( ! is_user_logged_in() || ! WC()->customer ) {
			return;
		}

		$customer = WC()->customer;
		$changed  = false;

		foreach ( array( 'billing', 'shipping' ) as $type ) {
			foreach ( array( 'first_name', 'last_name', 'company', 'country', 'state', 'postcode', 'city', 'address_1', 'address_2', 'phone', 'email' ) as $field ) {
				$key = $type . '_' . $field;
				$set = 'set_' . $key;

				if ( 'email' === $field && 'shipping' === $type ) {
					continue; /* shipping has no email */
				}

				$value = is_callable( array( $order, 'get_' . $key ) ) ? (string) $order->{'get_' . $key}() : '';
				if ( '' === trim( $value ) || ! is_callable( array( $customer, $set ) ) ) {
					continue;
				}

				if ( (string) $customer->{'get_' . $key}() !== $value ) {
					$customer->$set( $value );
					$changed = true;
				}
			}
		}

		/*
		 * "Ship to a different address" unchecked is the common case: the order
		 * carries billing only. Without this the address book kept telling the
		 * customer their shipping address was missing right after they had
		 * typed it.
		 */
		if ( '' === trim( (string) $customer->get_shipping_address_1() ) && '' !== trim( (string) $customer->get_billing_address_1() ) ) {
			foreach ( array( 'first_name', 'last_name', 'company', 'country', 'state', 'postcode', 'city', 'address_1', 'address_2' ) as $field ) {
				$get = 'get_billing_' . $field;
				$set = 'set_shipping_' . $field;
				$val = is_callable( array( $customer, $get ) ) ? (string) $customer->$get() : '';
				if ( '' !== trim( $val ) && is_callable( array( $customer, $set ) ) ) {
					$customer->$set( $val );
					$changed = true;
				}
			}
		}

		if ( $changed ) {
			$customer->save();
		}
	}

	/**
	 * The posted-data equivalent for WC_Checkout::create_order(), sourced from
	 * the customer (account address / session), the WC session note + gateway.
	 */
	protected function order_data( $request ) {
		$customer = WC()->customer;
		$fields   = array( 'first_name', 'last_name', 'company', 'country', 'state', 'postcode', 'city', 'address_1', 'address_2', 'phone', 'email' );
		$data     = array();

		foreach ( $fields as $field ) {
			$billing  = is_callable( array( $customer, 'get_billing_' . $field ) ) ? (string) $customer->{'get_billing_' . $field}() : '';
			$shipping = is_callable( array( $customer, 'get_shipping_' . $field ) ) ? (string) $customer->{'get_shipping_' . $field}() : '';
			$data[ 'billing_' . $field ]  = $billing;
			$data[ 'shipping_' . $field ] = $shipping;
		}

		if ( '' === $data['billing_email'] && is_user_logged_in() ) {
			$user                  = wp_get_current_user();
			$data['billing_email'] = (string) $user->user_email;
		}

		/*
		 * The SMS login already proved a number; a customer who logged in that
		 * way should not have to type it again — and a digital order has no
		 * address to fall back on.
		 */
		if ( '' === trim( (string) $data['billing_phone'] ) && class_exists( 'HSW_Checkout_Digital' ) ) {
			$verified = HSW_Checkout_Digital::verified_phone();
			if ( '' !== $verified ) {
				$data['billing_phone']   = $verified;
				$data['shipping_phone']  = $verified;
			}
		}

		/* WooCommerce's "ship to billing" default when no separate address exists. */
		foreach ( $fields as $field ) {
			if ( '' === $data[ 'shipping_' . $field ] ) {
				$data[ 'shipping_' . $field ] = $data[ 'billing_' . $field ];
			}
		}

		$method = (string) $request->get_param( 'method' );
		if ( '' === $method ) {
			$method = (string) WC()->session->get( 'chosen_payment_method' );
		}

		$data['payment_method']            = $method;
		$data['order_comments']            = $this->note_with_delivery();
		$data['ship_to_different_address'] = false;
		/*
		 * The design pay page renders the only terms acceptance point in the HSW
		 * flow. Its checkbox is therefore authoritative even when WooCommerce's
		 * separate terms page is not configured; the browser gate and the REST
		 * endpoint must agree, otherwise the client-side check is bypassable.
		 */
		$data['terms'] = (bool) $request->get_param( 'terms' );

		return $data;
	}

	/**
	 * The pay page re-sends the day/slot it kept from the checkout step (the
	 * CTA's keepalive request can be lost while the browser navigates).
	 * Request values win over the session; re-sanitized + length-capped.
	 */
	protected function store_schedule_from_request( $request ) {
		$day  = trim( sanitize_text_field( (string) $request->get_param( 'schedule_day' ) ) );
		$slot = trim( sanitize_text_field( (string) $request->get_param( 'schedule_slot' ) ) );

		if ( '' === $day && '' === $slot ) {
			return;
		}

		$cap = static function ( $value ) {
			$value = (string) $value;
			return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 120 ) : substr( $value, 0, 120 );
		};

		WC()->session->set(
			'hsw_delivery_schedule',
			array(
				'day'  => $cap( $day ),
				'slot' => $cap( $slot ),
			)
		);
	}

	/**
	 * Picked delivery day + time slot from the WC session ('' when the
	 * customer never chose or the schedule section is switched off).
	 *
	 * @return array{day:string,slot:string}
	 */
	protected function delivery_schedule() {
		$schedule = WC()->session ? WC()->session->get( 'hsw_delivery_schedule' ) : array();
		$day      = ( is_array( $schedule ) && isset( $schedule['day'] ) ) ? trim( (string) $schedule['day'] ) : '';
		$slot     = ( is_array( $schedule ) && isset( $schedule['slot'] ) ) ? trim( (string) $schedule['slot'] ) : '';

		return array( 'day' => $day, 'slot' => $slot );
	}

	/**
	 * The customer note with the delivery day/slot line appended, so the
	 * picked schedule shows up inside the order note (admin + emails).
	 */
	protected function note_with_delivery() {
		$note     = trim( (string) WC()->session->get( 'hsw_checkout_note' ) );
		$schedule = $this->delivery_schedule();
		$when     = trim( implode( ' — ', array_filter( array( $schedule['day'], $schedule['slot'] ) ) ) );

		if ( '' === $when ) {
			return $note;
		}

		$line = sprintf(
			/* translators: %s: picked delivery day + time slot. */
			__( 'زمان تحویل: %s', 'hamishop-elementor-widgets' ),
			$when
		);

		return ( '' === $note ) ? $line : $note . "\n" . $line;
	}

	/**
	 * When the customer never picked a shipping rate (our UI is radio cards),
	 * fall back to WooCommerce's own default: the first rate of each package.
	 */
	protected function maybe_default_shipping() {
		if ( ! WC()->cart->needs_shipping() ) {
			return;
		}
		$chosen = WC()->session->get( 'chosen_shipping_methods' );
		$chosen = is_array( $chosen ) ? array_filter( $chosen, 'strlen' ) : array();
		if ( $chosen ) {
			return;
		}
		$shipping = WC()->shipping();
		if ( ! $shipping ) {
			return;
		}
		$shipping->calculate_shipping( WC()->cart->get_shipping_packages() );
		$defaults = array();
		foreach ( (array) $shipping->get_packages() as $index => $package ) {
			if ( empty( $package['rates'] ) || ! is_array( $package['rates'] ) ) {
				continue;
			}
			$keys               = array_keys( $package['rates'] );
			$defaults[ $index ] = (string) $keys[0];
		}
		if ( $defaults ) {
			WC()->session->set( 'chosen_shipping_methods', $defaults );
		}
	}

	/**
	 * Required checkout fields + cart integrity + gateway rules.
	 * Returns an array of human messages (empty = valid).
	 */
	protected function validate( &$data ) {
		$messages = array();

		foreach ( (array) WC()->checkout()->get_checkout_fields() as $fieldset_key => $fieldset ) {
			/* WooCommerce skips the shipping fieldset when shipping to billing. */
			if ( 'shipping' === $fieldset_key && ( ! WC()->cart->needs_shipping() || empty( $data['ship_to_different_address'] ) ) ) {
				continue;
			}
			foreach ( $fieldset as $key => $field ) {
				if ( ! isset( $data[ $key ] ) ) {
					continue;
				}
				if ( ! empty( $field['required'] ) && '' === trim( (string) $data[ $key ] ) ) {
					$label      = isset( $field['label'] ) ? $field['label'] : $key;
					$messages[] = sprintf(
						/* translators: %s: checkout field label. */
						__( 'مقدار «%s» را کامل کنید.', 'hamishop-elementor-widgets' ),
						$label
					);
					continue;
				}
				$format = isset( $field['validate'] ) ? (array) $field['validate'] : array();
				if ( '' !== $data[ $key ] && in_array( 'email', $format, true ) && ! is_email( $data[ $key ] ) ) {
					$messages[] = __( 'ایمیل وارد شده معتبر نیست.', 'hamishop-elementor-widgets' );
				}
			}
		}

		/* Cart integrity: stock, sold-individually, … */
		$messages = array_merge( $messages, $this->collect_notices( array( WC()->cart, 'check_cart_items' ) ) );

		/* Shipping rate must exist for the destination (WC's own final check). */
		if ( ! $messages && WC()->cart->needs_shipping() ) {
			$chosen = WC()->session->get( 'chosen_shipping_methods' );
			foreach ( (array) WC()->shipping()->get_packages() as $i => $package ) {
				if ( ! isset( $chosen[ $i ], $package['rates'][ $chosen[ $i ] ] ) ) {
					$messages[] = __( 'برای این آدرس روش ارسال در دسترس نیست؛ آدرس را بررسی کنید.', 'hamishop-elementor-widgets' );
					break;
				}
			}
		}

		/* Gateway rules (most gateways validate nothing by default). */
		if ( WC()->cart->needs_payment() ) {
			$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->get_available_payment_gateways() : array();
			if ( ! isset( $gateways[ $data['payment_method'] ] ) ) {
				$messages[] = __( 'روش پرداخت انتخاب‌شده در دسترس نیست؛ روش دیگری را انتخاب کنید.', 'hamishop-elementor-widgets' );
			} else {
				$messages = array_merge( $messages, $this->collect_notices( array( $gateways[ $data['payment_method'] ], 'validate_fields' ) ) );
			}
		}

		/* Other checkout validators (field plugins, …) join through this hook. */
		$errors = new WP_Error();
		do_action( 'woocommerce_after_checkout_validation', $data, $errors );
		foreach ( $errors->get_error_messages() as $message ) {
			$messages[] = (string) $message;
		}

		return array_values( array_unique( array_filter( array_map( 'trim', $messages ) ) ) );
	}

	/**
	 * Run a callable that reports failure through wc_notices and collect them.
	 */
	protected function collect_notices( $callable ) {
		$messages = array();
		wc_clear_notices();
		if ( is_callable( $callable ) ) {
			try {
				call_user_func( $callable );
			} catch ( Throwable $e ) {
				$messages[] = wp_strip_all_tags( $e->getMessage() );
			}
		}
		foreach ( wc_get_notices( 'error' ) as $notice ) {
			$text = is_array( $notice ) && isset( $notice['notice'] ) ? $notice['notice'] : (string) $notice;
			$text = trim( wp_strip_all_tags( $text ) );
			if ( '' !== $text ) {
				$messages[] = $text;
			}
		}
		wc_clear_notices();
		return $messages;
	}

	/**
	 * Design extras that ride along with the order (legal-invoice request).
	 */
	protected function decorate_order( $order ) {
		if ( 'yes' === (string) WC()->session->get( 'hsw_checkout_invoice' ) ) {
			$order->update_meta_data( '_hsw_invoice_requested', 'yes' );
			$order->add_order_note( __( 'درخواست فاکتور رسمی از سوی مشتری ثبت شد.', 'hamishop-elementor-widgets' ) );
		}

		$schedule = $this->delivery_schedule();
		if ( '' !== $schedule['day'] ) {
			$order->update_meta_data( '_hsw_delivery_day', $schedule['day'] );
		}
		if ( '' !== $schedule['slot'] ) {
			$order->update_meta_data( '_hsw_delivery_slot', $schedule['slot'] );
		}

		$order->update_meta_data( '_hsw_placed_via', 'hamishop-pay' );
		$order->save();
	}
}
