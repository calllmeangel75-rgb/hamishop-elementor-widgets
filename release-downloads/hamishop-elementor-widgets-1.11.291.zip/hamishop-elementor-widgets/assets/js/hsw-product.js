/**
 * HamiShop Elementor Widgets — product page behavior.
 * Vanilla JS, no dependencies, event delegation only.
 * State engine: color/storage selection → matching variation → price/stock
 * sync across purchase box + sticky bar → AJAX add-to-cart with fragments.
 */
(function () {
	'use strict';

	var D = window.hswProductData || {};
	var FA = { '0': '۰', '1': '۱', '2': '۲', '3': '۳', '4': '۴', '۵': '۵', '5': '۵', '6': '۶', '7': '۷', '8': '۸', '9': '۹' };
	function fa(n) { return D.faDigits === false ? String(n) : String(n).replace(/[0-9]/g, function (d) { return FA[d]; }); }

	/* ---------- per-product state ---------- */
	var states = {};
	function state(pid) {
		if (!states[pid]) { states[pid] = { qty: 1, color: '', storage: '', chips: {}, variation: null, data: null, cartQty: 0, cartVariationId: 0 }; }
		if (!states[pid].chips) { states[pid].chips = {}; }
		return states[pid];
	}
	function payload(root) {
		var raw = root.getAttribute('data-hsw-variations');
		if (!raw) { return null; }
		try { return JSON.parse(raw); } catch (e) { return null; }
	}
	function attrMap(root) {
		var raw = root.getAttribute('data-hsw-attrs');
		try { return raw ? JSON.parse(raw) : {}; } catch (e) { return {}; }
	}
	function roots(pid) {
		return document.querySelectorAll('.hsw-p[data-hsw-product="' + pid + '"], .hsw-p[data-hsw-variants="' + pid + '"]');
	}

	/* ---------- simple-product attribute picker ---------- */
	/*
	 * A simple product can carry a visible colour attribute without being
	 * variable, so its picker has no variation to match. The only job here is to
	 * remember the answer and to keep the buy button locked until every group has
	 * one — the warehouse cannot ship "any colour".
	 */
	function pickerFor(pid) {
		return document.querySelector('[data-hsw-attr-picker][data-hsw-variants="' + pid + '"]');
	}

	function pickedValues(root) {
		var out = {};
		root.querySelectorAll('[data-hsw-pick-group]').forEach(function (g) {
			var tax = g.getAttribute('data-hsw-pick-group');
			if (out[tax] === undefined) { out[tax] = ''; }
		});
		root.querySelectorAll('[data-hsw-pick].is-active').forEach(function (b) {
			out[b.getAttribute('data-hsw-pick')] = b.getAttribute('data-hsw-pick-value');
		});
		return out;
	}

	function paintPick(root, tax, value, text) {
		root.querySelectorAll('[data-hsw-pick]').forEach(function (b) {
			/*
			 * Only the group being answered is repainted. Clearing every button
			 * that is not part of this group wiped the other answers, so a
			 * product with two visible attributes («رنگ» + «نوک») could never
			 * unlock the buy button: every pick erased the previous one.
			 */
			if (b.getAttribute('data-hsw-pick') !== tax) { return; }
			var on = (b.getAttribute('data-hsw-pick-value') === value);
			b.classList.toggle('is-active', on);
			b.setAttribute('aria-pressed', on ? 'true' : 'false');
		});
		root.querySelectorAll('[data-hsw-pick-group="' + tax + '"]').forEach(function (g) {
			var name = g.querySelector('[data-hsw-pick-name]');
			if (!name) { return; }
			name.textContent = text || '';
			name.classList.toggle('is-empty', !text);
		});
	}

	/* Returns the label of the first unanswered group, or '' when all are set. */
	function gateAddButtons(root) {
		var pid = root.getAttribute('data-hsw-variants') || '';
		var picked = pickedValues(root);
		var missing = '';

		root.querySelectorAll('[data-hsw-pick-group]').forEach(function (g) {
			var tax = g.getAttribute('data-hsw-pick-group');
			if (!missing && !picked[tax]) {
				missing = g.getAttribute('data-hsw-pick-label') || tax;
			}
		});

		var scopes = pid ? roots(pid) : [root];
		Array.prototype.forEach.call(scopes, function (scope) {
			scope.querySelectorAll('[data-hsw-add]').forEach(function (btn) {
				btn.classList.toggle('is-locked', !!missing);
				if (missing) {
					btn.setAttribute('aria-disabled', 'true');
					btn.setAttribute('data-hsw-need-attr', missing);
				} else {
					btn.removeAttribute('aria-disabled');
					btn.removeAttribute('data-hsw-need-attr');
				}
			});
		});

		return missing;
	}

	/* ---------- variation matching ---------- */
	/*
	 * One selection map covers every picker: the colour role, the primary chip
	 * group (legacy `storage`) and any number of extra chip groups (`chips`).
	 * The variation with the most matching attributes wins; a variation that
	 * contradicts a selection is never chosen.
	 */
	function matchVariation(list, map, st) {
		if (!list || !list.length) { return null; }
		st = st || {};

		var sel = {};
		if (map.color) { sel[map.color] = st.color; }
		if (map.storage) { sel[map.storage] = st.storage; }
		(map.chips || []).forEach(function (tax) {
			var value = st.chips && st.chips[tax];
			if (value) { sel[tax] = value; }
		});

		var keys = Object.keys(sel).filter(function (k) { return !!sel[k]; });
		var best = null, bestScore = -1;

		for (var i = 0; i < list.length; i++) {
			var v = list[i], score = 0, ok = true;
			for (var k = 0; k < keys.length; k++) {
				var want = sel[keys[k]];
				var have = v.attrs && v.attrs[keys[k]];
				if (!have) { continue; }            // wildcard / not part of this variation
				if (have === want) { score++; } else { ok = false; break; }
			}
			if (!ok) { continue; }
			if (score > bestScore) { bestScore = score; best = v; }
			if (score === keys.length) { break; }
		}
		/*
		 * No silent `list[0]` fallback: it used to show the first variation's
		 * price and add that variation to the cart even when the customer had
		 * asked for something the product does not offer. The caller marks the
		 * combination unavailable instead.
		 */
		return best;
	}

	/* Every picker group answered? Only then can a miss mean "no such combination". */
	function selectionComplete(map, st) {
		var need = [];
		if (map.color) { need.push(st.color); }
		if (map.storage) { need.push(st.storage); }
		(map.chips || []).forEach(function (tax) {
			need.push(st.chips && st.chips[tax]);
		});
		return need.length > 0 && need.every(function (v) { return !!v; });
	}

	/* ---------- render variant-dependent fields ---------- */
	function applyVariant(pid, variation, dead) {
		var st = state(pid);
		st.variation = variation || null;
		st.dead = !!dead;
		roots(pid).forEach(function (root) {
			var cfp = root.hasAttribute('data-hsw-cfp') || root.getAttribute('data-hsw-cfp') === '1';
			var price = root.querySelector('[data-hsw-price]');
			var old = root.querySelector('[data-hsw-old]');
			var save = root.querySelector('[data-hsw-save]');
			var off = root.querySelector('[data-hsw-off]');

			/* The selected combination does not exist: never show a price or
			 * allow an add that would send the wrong variation. */
			if (dead) {
				root.classList.add('is-unavailable');
				if (price) { price.textContent = '—'; }
				if (old) { old.style.display = 'none'; }
				if (save) { save.style.display = 'none'; }
				if (off) { off.style.display = 'none'; }
				root.querySelectorAll('[data-hsw-add]').forEach(function (btn) {
					btn.classList.add('is-locked');
					btn.setAttribute('aria-disabled', 'true');
					btn.setAttribute('data-hsw-unavailable', '1');
				});
				return;
			}

			root.classList.remove('is-unavailable');
			root.querySelectorAll('[data-hsw-add][data-hsw-unavailable]').forEach(function (btn) {
				btn.classList.remove('is-locked');
				btn.removeAttribute('aria-disabled');
				btn.removeAttribute('data-hsw-unavailable');
			});

			if (variation && !cfp) {
				if (price) { price.textContent = variation.price; }
				if (old) {
					old.textContent = variation.regular;
					old.style.display = (variation.discount > 0) ? '' : 'none';
				}
				if (save) {
					if (variation.save_html) { save.textContent = variation.save_html; }
					save.style.display = (variation.discount > 0) ? '' : 'none';
				}
				if (off) {
					off.textContent = fa(variation.discount) + '٪';
					off.style.display = (variation.discount > 0) ? '' : 'none';
				}
				root.classList.toggle('is-oos', !variation.in_stock);
			}
			/* gallery image swap */
			if (variation && variation.image) {
				var img = root.querySelector('.hsw-pgal__img');
				if (img) { img.src = variation.image; }
			}

			/*
			 * The stepper belongs to the selected variation, not to the
			 * product: switching to a variation that is not in the cart must
			 * close it again (and seed it with the real line quantity when it
			 * is).
			 */
			if (variation) {
				/*
				 * The line belongs to one variation. Switching to a different
				 * one must close the stepper even if the product (or another
				 * variation) is in the cart.
				 */
				var own = (st.cartVariationId && variation.id === st.cartVariationId) ? (st.cartQty || 0) : 0;
				var cq  = Math.max(parseInt(variation.cart_qty || 0, 10) || 0, own);
				root.classList.toggle('is-not-in-cart', cq <= 0);
				root.setAttribute('data-hsw-in-cart', String(cq));
				/* The input and the bin/minus state must follow the variation too. */
				setQty(pid, cq > 0 ? cq : 1);
			}
		});
		document.dispatchEvent(new CustomEvent('hsw:variant', { detail: { product: pid, variation: variation, state: st } }));
	}

	function refreshVariant(pid) {
		var st = state(pid);
		var any = document.querySelector('.hsw-p[data-hsw-variations][data-hsw-product="' + pid + '"], .hsw-p[data-hsw-variations][data-hsw-variants="' + pid + '"]');
		if (!any) { return; }
		var list = payload(any);
		var map = attrMap(any);
		var match = matchVariation(list, map, st);
		applyVariant(pid, match, !match && selectionComplete(map, st));
	}

	/* ---------- reviews ---------- */
	function openReviews() {
		var tabs = document.querySelector('.hsw-ptabs');
		if (tabs && window.getComputedStyle(tabs).display !== 'none') {
			var btn = tabs.querySelector('.hsw-ptabs__btn[data-hsw-tab="comments"]');
			var panel = tabs.querySelector('.hsw-ptabs__panel[data-hsw-panel="comments"]');
			if (btn && panel) {
				tabs.querySelectorAll('.hsw-ptabs__btn').forEach(function (b) { b.classList.toggle('is-active', b === btn); });
				tabs.querySelectorAll('.hsw-ptabs__panel').forEach(function (p) { p.classList.toggle('is-active', p === panel); });
				scrollTo(panel);
				return;
			}
		}
		var item = document.querySelector('.hsw-pacc [data-hsw-acc-item="reviews"]');
		if (item) {
			item.classList.add('is-open');
			scrollTo(item);
			return;
		}
		var fallback = document.querySelector('#reviews');
		if (fallback) { scrollTo(fallback); }
	}
	function focusReviewForm(trigger) {
		var scope = trigger.closest('[data-hsw-panel="comments"], [data-hsw-acc-item="reviews"]') || document;
		var form = scope.querySelector('.hsw-review-form');
		if (!form) { openReviews(); return; }
		scrollTo(form);
		var textarea = form.querySelector('textarea[name="comment"]');
		if (textarea) {
			setTimeout(function () {
				try { textarea.focus({ preventScroll: true }); } catch (e) { textarea.focus(); }
			}, 250);
		}
	}
	function submitReviewForm(form) {
		if (!window.fetch || !window.FormData || form.classList.contains('is-busy')) { return; }
		var submit = form.querySelector('.hsw-review-submit, [type="submit"]');
		var origLabel = submit ? (submit.value || submit.textContent || '') : '';
		var msgBox = form.querySelector('.hsw-review-pending');
		if (!msgBox) {
			msgBox = document.createElement('p');
			msgBox.className = 'hsw-review-pending';
			msgBox.setAttribute('role', 'status');
			form.insertBefore(msgBox, form.firstChild);
		}
		msgBox.className = 'hsw-review-pending';
		msgBox.textContent = '';
		msgBox.hidden = true;

		form.classList.add('is-busy');
		if (submit) {
			submit.disabled = true;
			if ('INPUT' === submit.tagName) {
				submit.value = 'در حال ارسال...';
			} else {
				submit.textContent = 'در حال ارسال...';
			}
		}

		var fd = new FormData(form);
		fd.set('action', 'hsw_submit_comment');
		fd.set('hsw_ajax', '1');
		var ajaxUrl = form.getAttribute('data-hsw-ajax-url') || (window.hswProductData && window.hswProductData.ajaxUrl) || '/wp-admin/admin-ajax.php';

		window.fetch(ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: fd
		})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				var ok = !!(res && res.success && res.data);
				var text = (res && res.data && res.data.message) ? res.data.message : (ok ? 'دیدگاه شما با موفقیت ثبت شد.' : 'ثبت دیدگاه انجام نشد. لطفاً دوباره تلاش کنید.');
				msgBox.className = 'hsw-review-pending ' + (ok ? 'is-ok' : 'is-err');
				msgBox.textContent = text;
				msgBox.hidden = false;

				if (window.HSWFeedback && window.HSWFeedback.toast) {
					window.HSWFeedback.toast(text, { tone: ok ? 'ok' : 'error' });
				}

				if (ok) {
					var textarea = form.querySelector('textarea[name="comment"]');
					if (textarea) { textarea.value = ''; }
					form.querySelectorAll('input[name="rating"]:checked').forEach(function (inp) { inp.checked = false; });
				}
			})
			.catch(function () {
				var errMsg = 'خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.';
				msgBox.className = 'hsw-review-pending is-err';
				msgBox.textContent = errMsg;
				msgBox.hidden = false;
				if (window.HSWFeedback && window.HSWFeedback.toast) {
					window.HSWFeedback.toast(errMsg, { tone: 'error' });
				}
			})
			.finally(function () {
				form.classList.remove('is-busy');
				if (submit) {
					submit.disabled = false;
					if ('INPUT' === submit.tagName) {
						submit.value = origLabel;
					} else {
						submit.textContent = origLabel;
					}
				}
			});
	}

	document.addEventListener('submit', function (e) {
		var form = e.target && e.target.closest ? e.target.closest('.hsw-review-form') : null;
		if (!form || !window.fetch || !window.FormData) { return; }
		e.preventDefault();
		submitReviewForm(form);
	});

	function scrollTo(el) {
		if (!el) { return; }
		var stackRoot = el.closest && el.closest('.hsw-ptabs--stack, [data-hsw-ptabs-stack]');
		if (stackRoot) {
			scrollToStackPanel(stackRoot, el);
			return;
		}
		if (el.scrollIntoView) { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
	}

	function stackHeaderBottom() {
		var top = 0;
		var adminBar = document.getElementById('wpadminbar');
		if (adminBar) {
			var ar = adminBar.getBoundingClientRect();
			var apos = getComputedStyle(adminBar).position;
			if ((apos === 'fixed' || apos === 'sticky') && ar.height > 0 && ar.bottom > top) {
				top = ar.bottom;
			}
		}
		var hds = document.querySelectorAll('.hsw-hd--sticky, header, .elementor-location-header');
		for (var i = 0; i < hds.length; i++) {
			var hd = hds[i];
			if (!hd.offsetWidth || hd.classList.contains('is-hidden')) { continue; }
			var cs = getComputedStyle(hd);
			var pos = cs.position;
			var target = hd;
			if (pos !== 'fixed' && pos !== 'sticky') {
				var fixedChild = hd.querySelector('.is-fixed, .elementor-sticky--active');
				if (!fixedChild) { continue; }
				target = fixedChild;
			}
			var r = target.getBoundingClientRect();
			if (r.height > 0 && r.top <= top + 24 && r.bottom > top && r.bottom < window.innerHeight * 0.45) {
				top = r.bottom;
			}
		}
		return Math.max(0, Math.round(top));
	}

	function scrollToStackPanel(stackRoot, targetEl) {
		var wrap = stackRoot.querySelector('.hsw-ptabs__navwrap');
		var navH = (wrap && wrap.offsetHeight) ? wrap.offsetHeight : 56;
		var rawGap = getComputedStyle(stackRoot).getPropertyValue('--hsw-stk-gap') || '8px';
		var gap = parseFloat(rawGap);
		if (isNaN(gap)) { gap = 8; }
		var hBottom = stackHeaderBottom();
		var offset = hBottom + Math.max(0, gap) + navH + 12;
		var rect = targetEl.getBoundingClientRect();
		var destY = Math.max(0, Math.round(window.pageYOffset + rect.top - offset));
		stackRoot._hswLockUntil = Date.now() + 700;
		window.scrollTo({ top: destY, behavior: 'smooth' });
	}

	/* ================= CLICK DELEGATION ================= */
	document.addEventListener('click', function (e) {
		var t = e.target;

		/* --- tabs --- */
		var tabBtn = t.closest('.hsw-ptabs__btn');
		if (tabBtn) {
			var tabsRoot = tabBtn.closest('.hsw-ptabs');
			var id = tabBtn.getAttribute('data-hsw-tab');
			tabsRoot._hswActiveId = id;
			tabsRoot.querySelectorAll('.hsw-ptabs__btn').forEach(function (b) { b.classList.toggle('is-active', b === tabBtn); });
			tabsRoot.querySelectorAll('.hsw-ptabs__panel').forEach(function (p) { p.classList.toggle('is-active', p.getAttribute('data-hsw-panel') === id); });
			if (tabsRoot.classList.contains('hsw-ptabs--stack') || tabsRoot.hasAttribute('data-hsw-ptabs-stack')) {
				var targetPanel = tabsRoot.querySelector('.hsw-ptabs__panel[data-hsw-panel="' + id + '"]');
				if (targetPanel) { scrollTo(targetPanel); }
			}
			return;
		}

		/* --- product rating link → open the reviews tab / accordion --- */
		var reviewLink = t.closest('a[href="#reviews"], .hsw-ptitle__revlink');
		if (reviewLink) {
			e.preventDefault();
			openReviews();
			return;
		}

		/* --- "add a review" link → scroll to the real form --- */
		var addReview = t.closest('[data-hsw-add-review]');
		if (addReview) {
			e.preventDefault();
			focusReviewForm(addReview);
			return;
		}

		/* --- accordion --- */
		var acc = t.closest('[data-hsw-acc]');
		if (acc) {
			acc.closest('.hsw-pacc__item').classList.toggle('is-open');
			return;
		}

		/* --- gallery thumbs / dots --- */
		var thumb = t.closest('.hsw-pgal__thumb, .hsw-pgal__dot');
		if (thumb) {
			var gal = thumb.closest('.hsw-pgal');
			var src = thumb.getAttribute('data-hsw-src');
			var img = gal && gal.querySelector('.hsw-pgal__img');
			gal.querySelectorAll('.hsw-pgal__thumb, .hsw-pgal__dot').forEach(function (b) { b.classList.toggle('is-active', b === thumb); });
			if (img && src) { img.src = src; }
			/* Keep the chosen thumbnail centred in its own carousel row. */
			if (thumb.classList.contains('hsw-pgal__thumb') && thumb.scrollIntoView) {
				thumb.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
			}
			return;
		}

		/* --- zoom / lightbox --- */
		var zoomBtn = t.closest('[data-hsw-zoom]');
		if (zoomBtn) {
			var scope = zoomBtn.closest('.hsw-p');
			var gal   = scope && scope.querySelector('.hsw-pgal');
			var main  = scope && scope.querySelector('.hsw-pgal__img');
			var src   = main ? (main.currentSrc || main.src) : '';
			var list  = [];
			try {
				list = JSON.parse(gal ? (gal.getAttribute('data-hsw-images') || '[]') : '[]');
			} catch (e) { list = []; }
			if (!Array.isArray(list) || !list.length) { list = src ? [src] : []; }
			var idx = list.indexOf(src);
			openZoom(list, idx < 0 ? 0 : idx);
			return;
		}

		/* --- wishlist (visual toggle) --- */
		var wish = t.closest('[data-hsw-wish]');
		if (wish) {
			var ic = wish.querySelector('.hsw-ic');
			var on = wish.classList.toggle('is-active');
			if (ic) { window.hswFill(ic, on); ic.style.color = on ? 'var(--hsw-secondary)' : ''; }
			return;
		}

		/* --- color swatch --- */
		/*
		 * The simple-product picker reuses the swatch/chip classes for its look,
		 * but it has no variation to match — let its own branch below handle it.
		 */
		var sw = t.closest('.hsw-pvar__swatch, .hsw-pvar__mswatch');
		if (sw && sw.closest('[data-hsw-attr-picker]')) { sw = null; }
		if (sw) {
			var vr = sw.closest('.hsw-pvar');
			var pid = vr.getAttribute('data-hsw-variants') || vr.getAttribute('data-hsw-product');
			var st = state(pid);
			st.color = sw.getAttribute('data-hsw-color') || '';
			var colorLabel = sw.getAttribute('data-hsw-label') || st.color;
			/* Desktop and mobile render the same list: keep both in sync. */
			vr.querySelectorAll('[data-hsw-color]').forEach(function (b) {
				b.classList.toggle('is-active', b.getAttribute('data-hsw-color') === st.color);
			});
			vr.querySelectorAll('[data-hsw-selname="color"]').forEach(function (el) { el.textContent = colorLabel; });
			refreshVariant(pid);
			return;
		}

		/* --- attribute chips (ram, ssd, size, …) --- */
		var chip = t.closest('.hsw-pvar__chip, .hsw-pvar__mchip');
		if (chip && chip.closest('[data-hsw-attr-picker]')) { chip = null; }
		if (chip) {
			var vr2 = chip.closest('.hsw-pvar');
			var pid2 = vr2.getAttribute('data-hsw-variants') || vr2.getAttribute('data-hsw-product');
			var tax = chip.getAttribute('data-hsw-attr') || 'storage';
			var val = chip.getAttribute('data-hsw-val') || chip.getAttribute('data-hsw-storage') || '';

			vr2.querySelectorAll('[data-hsw-attr]').forEach(function (b) {
				if (b.getAttribute('data-hsw-attr') !== tax) { return; }
				b.classList.toggle('is-active', (b.getAttribute('data-hsw-val') || b.getAttribute('data-hsw-storage')) === val);
			});

			var st2 = state(pid2);
			st2.chips[tax] = val;
			if (attrMap(vr2).storage === tax) { st2.storage = val; }
			vr2.querySelectorAll('[data-hsw-selname]').forEach(function (el) {
				if (el.getAttribute('data-hsw-selname') === tax || el.getAttribute('data-hsw-selname-alias') === tax) {
					el.textContent = val;
				}
			});
			refreshVariant(pid2);
			return;
		}

		/* --- quantity --- */
		var qb = t.closest('[data-hsw-qty]');
		if (qb) {
			var scope2 = qb.closest('.hsw-p');
			var pid3 = scope2.getAttribute('data-hsw-product');
			var st3 = state(pid3);
			var delta = parseInt(qb.getAttribute('data-hsw-qty'), 10) || 0;
			var next = setQty(pid3, st3.qty + delta);
			/*
			 * «کنار دکمهٔ خرید» is a local picker: the number travels with the
			 * add, never on its own. The default stepper still edits the cart.
			 */
			if (!scope2.classList.contains('hsw-ppurch--buy-inline') && !scope2.classList.contains('is-not-in-cart')) {
				pushQty(pid3, next);
			}
			return;
		}

		/* --- bin (only shown at quantity 1) --- */
		var delBtn = t.closest('[data-hsw-del]');
		if (delBtn) {
			var scopeD = delBtn.closest('.hsw-p');
			var pidD   = scopeD ? (scopeD.getAttribute('data-hsw-product') || scopeD.getAttribute('data-hsw-variants')) : '';
			if (pidD && D.qtyAjax && scopeD && !scopeD.classList.contains('is-not-in-cart')) {
				pushQty(pidD, 0).then(function () {
					setRootInCart(pidD, false);
					setQty(pidD, 1);
				});
				return;
			}
			var href = delBtn.getAttribute('data-hsw-del') || '';
			if (href) { window.location.href = href; }
			return;
		}

	/* --- attribute picker (simple products) --- */
	var pickChip = t.closest('[data-hsw-pick]');
	if (pickChip) {
		var pickRoot = pickChip.closest('[data-hsw-attr-picker]');
		if (!pickRoot) { return; }
		var pickTax = pickChip.getAttribute('data-hsw-pick');
		var pickVal = pickChip.getAttribute('data-hsw-pick-value');
		var pickTxt = pickChip.getAttribute('data-hsw-pick-text') || '';
		var wasOn = pickChip.classList.contains('is-active');
		paintPick(pickRoot, pickTax, wasOn ? '' : pickVal, wasOn ? '' : pickTxt);
		gateAddButtons(pickRoot);
		return;
	}

	/* --- add to cart --- */
	var addBtn = t.closest('[data-hsw-add]');
	if (addBtn) {
		var scope3 = addBtn.closest('.hsw-p');
		if (!scope3 || scope3.hasAttribute('data-hsw-cfp')) { return; }
		var pid4 = scope3.getAttribute('data-hsw-product');

		/*
		 * The customer answered every picker but the product has no such
		 * variation (e.g. «A4» only comes in black). Nothing may be added: the
		 * old code sent the first variation instead, so the order said one
		 * thing and the customer had chosen another.
		 */
		if (addBtn.getAttribute('data-hsw-unavailable') === '1') {
			var noMatch = document.querySelector('.hsw-p[data-hsw-variations][data-hsw-product="' + pid4 + '"]');
			var noMsg = noMatch ? (noMatch.getAttribute('data-hsw-no-match') || '') : '';
			if (window.HSWFeedback && window.HSWFeedback.toast) {
				window.HSWFeedback.toast(noMsg || 'این ترکیب موجود نیست.', { tone: 'error' });
			}
			return;
		}

		/* Locked until the colour/size picker has an answer. */
		if (addBtn.classList.contains('is-locked')) {
			var need = addBtn.getAttribute('data-hsw-need-attr') || '';
			var picker = pickerFor(pid4);
			var tpl = picker ? (picker.getAttribute('data-hsw-pick-msg') || '') : '';
			var text = tpl ? tpl.replace('%s', need) : ('ابتدا ' + (need || 'ویژگی محصول') + ' را انتخاب کنید.');
			if (window.HSWFeedback && window.HSWFeedback.toast) {
				window.HSWFeedback.toast(text, { tone: 'error' });
			}
			if (picker && picker.scrollIntoView) {
				picker.scrollIntoView({ behavior: 'smooth', block: 'center' });
			}
			return;
		}

		var st4 = state(pid4);
		addToCart(addBtn, pid4, st4);
		return;
	}
	});

	/* ---------- quantity ---------- */

	/* First paint: mark every stepper that starts at 1. */
	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('.hsw-psticky__stepper, .hsw-ppurch__stepper').forEach(function (box) {
			var val = box.querySelector('[data-hsw-qval]');
			var n = val ? parseInt(String(val.value).replace(/[^0-9]/g, ''), 10) : 1;
			box.classList.toggle('is-min', !(n > 1));
		});

		/* A simple product's picker starts unanswered: keep the buy button locked. */
		document.querySelectorAll('[data-hsw-attr-picker]').forEach(function (root) {
			gateAddButtons(root);
		});
	});

	/* Persian/Arabic digits are what a Persian keyboard produces. */
	function toLatin(value) {
		return String(value)
			.replace(/[\u06F0-\u06F9]/g, function (d) { return String(d.charCodeAt(0) - 0x06F0); })
			.replace(/[\u0660-\u0669]/g, function (d) { return String(d.charCodeAt(0) - 0x0660); })
			.replace(/[^\d]/g, '');
	}

	/* The stepper and the typed field share one source of truth: state().qty. */
	function setQty(pid, value) {
		var st = state(pid);
		var qty = parseInt(value, 10);
		if (isNaN(qty)) { qty = 1; }
		st.qty = Math.max(1, Math.min(99, qty));

		roots(pid).forEach(function (r) {
			r.querySelectorAll('[data-hsw-qval]').forEach(function (el) {
				if ('INPUT' === el.tagName) {
					el.value = fa(st.qty);
				} else {
					el.textContent = fa(st.qty);
				}
			});
			/* Quantity 1: the minus becomes the bin (see the stylesheet). */
			r.querySelectorAll('.hsw-psticky__stepper, .hsw-ppurch__stepper').forEach(function (box) {
				box.classList.toggle('is-min', st.qty <= 1);
			});
			if (!r.classList.contains('is-not-in-cart')) {
				r.setAttribute('data-hsw-in-cart', String(st.qty));
			}
		});
		return st.qty;
	}

	function commitQty(el) {
		var scope = el.closest('.hsw-p');
		if (!scope) { return; }
		var pid = scope.getAttribute('data-hsw-product') || scope.getAttribute('data-hsw-variants');
		if (!pid) { return; }
		var raw = toLatin(el.value);
		var qty = raw === '' ? 1 : parseInt(raw, 10);
		if (isNaN(qty) || qty < 1) { qty = 1; }
		qty = setQty(pid, qty);
		if (!scope.classList.contains('is-not-in-cart')) {
			pushQty(pid, qty);
		}
	}

	document.addEventListener('keydown', function (e) {
		var el = e.target;
		if (!el || !el.hasAttribute || !el.hasAttribute('data-hsw-qval')) { return; }
		if ('Enter' === e.key) {
			e.preventDefault();
			commitQty(el);
			el.blur();
		}
	});

	document.addEventListener('change', function (e) {
		var el = e.target;
		if (!el || !el.hasAttribute || !el.hasAttribute('data-hsw-qval')) { return; }
		commitQty(el);
	});

	document.addEventListener('focusin', function (e) {
		var el = e.target;
		if (el && el.hasAttribute && el.hasAttribute('data-hsw-qval') && 'INPUT' === el.tagName) {
			el.select();
		}
	});

	/* ================= CART SYNC ================= */

	/*
	 * The stepper edits a real cart line. Before this, pressing + only changed
	 * the number on screen — the customer picked 3 and received 1.
	 */
	function applyFragments(fragments) {
		if (!fragments) { return; }
		Object.keys(fragments).forEach(function (key) {
			document.querySelectorAll(key).forEach(function (n) { n.outerHTML = fragments[key]; });
		});
		/* Keep the dimmed "empty cart" styling in sync with the new count. */
		document.querySelectorAll('.hsw-hd__cart').forEach(function (cart) {
			var badge = cart.querySelector('[data-hsw-cart-count]');
			var n = badge ? parseInt(badge.getAttribute('data-count') || '0', 10) : 0;
			cart.classList.toggle('is-empty', !n);
		});
		/*
		 * WooCommerce listens for `wc_fragments_refreshed`; the old name was a
		 * no-op. Also tell the header widget explicitly, exactly like the loop
		 * and archive widgets do after their own add-to-cart.
		 */
		document.body.dispatchEvent(new Event('wc_fragments_refreshed'));
	}

	function setRootInCart(pid, inCart, qty) {
		var n = parseInt(qty, 10);
		if (isNaN(n) || n < 0) { n = 1; }
		/* Mirror the real quantity onto the selected variation. */
		var st = state(pid);
		if (st.variation) { st.variation.cart_qty = inCart ? n : 0; }
		st.cartQty = inCart ? n : 0;
		st.cartVariationId = inCart && st.variation ? st.variation.id : 0;
		roots(pid).forEach(function (r) {
			r.classList.toggle('is-not-in-cart', !inCart);
			/* The real cart quantity, never a boolean: addToCart() reads it back. */
			r.setAttribute('data-hsw-in-cart', inCart ? String(n) : '0');
			/* A page cached before the first add may carry a disabled bin. */
			r.querySelectorAll('[data-hsw-del][disabled]').forEach(function (b) { b.removeAttribute('disabled'); });
			/*
			 * The bin replaces the minus at quantity 1 only. This class used to be
			 * rendered server-side and never updated, so the bin stayed at 6 and
			 * removed the whole line.
			 */
			r.querySelectorAll('.hsw-psticky__stepper').forEach(function (st) {
				st.classList.toggle('is-min', n <= 1);
			});
		});
	}

	/*
	 * The header cart sidebar can remove or re-quantify the same line. Refresh
	 * the purchase box/sticky bar immediately, otherwise they keep claiming
	 * the product is still in the cart (CTA hidden, stepper visible) after the
	 * visitor emptied it from the drawer.
	 */
	document.addEventListener('hsw_cart_drawer_updated', function (event) {
		var d = event && event.detail ? event.detail : {};
		var pid = parseInt(d.productId, 10) || 0;
		if (!pid) { return; }
		var vid = parseInt(d.variationId, 10) || 0;
		var qty = parseInt(d.qty, 10);
		if (isNaN(qty) || qty < 0) { qty = 0; }

		var st = state(pid);
		if (st.data && st.data.variations && vid) {
			st.data.variations.forEach(function (v) {
				if (parseInt(v.id, 10) === vid) { v.cart_qty = qty; }
			});
		}
		/* This line belongs to another variation than the one on screen. */
		if (vid && (!st.variation || parseInt(st.variation.id, 10) !== vid)) {
			return;
		}

		setRootInCart(pid, qty > 0, qty > 0 ? qty : 1);
		setQty(pid, qty > 0 ? qty : 1);
	});

	function pushQty(pid, qty) {
		if (!D.qtyAjax) { return Promise.resolve(null); }
		var st = state(pid);
		var body = new URLSearchParams();
		body.set('product_id', pid);
		if (st.variation && st.variation.id) { body.set('variation_id', st.variation.id); }
		body.set('quantity', qty);
		body.set('security', D.qtyNonce || '');

		function send() {
			return fetch(D.qtyAjax, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body.toString()
			});
		}

		/*
		 * A page served from a full-page cache carries an expired nonce. Refresh it
		 * once (never in a loop) and replay the same request.
		 */
		function withFreshNonce() {
			if (!D.nonceUrl) { return Promise.reject(new Error('no-nonce-endpoint')); }
			return fetch(D.nonceUrl, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (j) {
					var n = j && (j.nonce || (j.data && j.data.nonce));
					if (!n) { throw new Error('no-nonce'); }
					D.qtyNonce = n;
					body.set('security', n);
					return send();
				});
		}

		return send().then(function (r) {
			if (r.status === 403) {
				return withFreshNonce().then(function (r2) {
					if (r2.status === 403) { throw new Error('nonce'); }
					return r2;
				});
			}
			return r;
		}).then(function (r) { return r.json(); }).then(function (res) {
			if (!res || !res.success) {
				var msg = res && res.data && res.data.message ? res.data.message : '';
				if (msg && typeof toast === 'function') { toast(msg); }
				return null;
			}
			applyFragments(res.data && res.data.fragments);
			var qty = res.data && typeof res.data.quantity === 'number' ? res.data.quantity : 0;
			/* The server is the source of truth for the ceiling. */
			if (res.data && typeof res.data.max === 'number' && res.data.max > 0) {
				D.maxQty = res.data.max;
			}
			setRootInCart(pid, !!(res.data && res.data.in_cart), qty);
			if (qty > 0) { setQty(pid, qty); }
			return res.data;
		}).catch(function (err) {
			if (err && err.message === 'nonce' && typeof toast === 'function') {
				toast('نشست شما منقضی شده است؛ صفحه را یک‌بار تازه کنید.');
			}
			return null;
		});
	}

	/* ================= ADD TO CART ================= */

	function addToCart(btn, pid, st) {
		if (document.body.classList.contains('elementor-editor-active')) { flashAdded(btn); return; }
		if (!pid || btn.classList.contains('is-busy')) { return; }
		btn.classList.add('is-busy');

		var scope     = btn.closest('.hsw-p');
		var inCart    = !!(scope && !scope.classList.contains('is-not-in-cart'));
		var inline    = !!(scope && scope.classList.contains('hsw-ppurch--buy-inline'));
		var beforeQty = scope ? (parseInt(scope.getAttribute('data-hsw-in-cart') || '0', 10) || 0) : 0;
		/*
		 * Already in the cart? The default stepper is a cart editor, so «خرید
		 * آنلاین» adds one more. In the inline mode the stepper is the quantity
		 * the customer picked, in or out of the cart.
		 */
		var addQty    = inline ? (st.qty || 1) : (inCart ? 1 : (st.qty || 1));

		var body = new URLSearchParams();
		body.set('action', 'hsw_add_to_cart'); /* unused; wc-ajax endpoint ignores action */
		body.set('product_id', st.variation && st.variation.id ? st.variation.id : pid);
		if (st.variation && st.variation.id) { body.set('variation_id', st.variation.id); }
		body.set('quantity', addQty);

		/*
		 * Simple product with a colour/size picker: the answer travels with the
		 * add so WooCommerce can store it on the cart line and the order. A
		 * variable product never reaches this branch — it sends variation_id.
		 */
		var picker = pickerFor(pid);
		if (picker && !(st.variation && st.variation.id)) {
			var picked = pickedValues(picker);
			Object.keys(picked).forEach(function (tax) {
				if (picked[tax]) { body.set('attribute_' + tax, picked[tax]); }
			});
		}

		var url = D.wcAjax || '/?wc-ajax=add_to_cart';
		fetch(url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (r) { return r.json(); }).then(function (res) {
			btn.classList.remove('is-busy');
			if (res && res.error && res.product_url) { window.location = res.product_url; return; }
			flashAdded(btn);
			showAdded(btn, pid, res);
			/* Same event the loop and archive widgets fire, so the header badge
			   refreshes through one code path. */
			document.dispatchEvent(new CustomEvent('hsw_added_to_cart', { detail: { productId: pid } }));

			/*
			 * The item is in the cart now: reveal the stepper (it is hidden
			 * before the first add) and seed it with the new line quantity.
			 * WooCommerce adds the requested quantity to an existing line, so
			 * the stepper, data-hsw-in-cart and the header badge stay identical.
			 */
			var newQty = inCart ? beforeQty + 1 : addQty;
			setRootInCart(pid, true, newQty);
			setQty(pid, newQty);

			applyFragments(res && res.fragments);
		}).catch(function () {
			btn.classList.remove('is-busy');
		});
	}
	function flashAdded(btn) {
		btn.classList.add('is-added');
		setTimeout(function () { btn.classList.remove('is-added'); }, 2000);
	}
	/*
	 * Success feedback. The in-widget toast only exists inside the sticky bar,
	 * so on desktop (where that bar is hidden) adding to the cart gave no
	 * feedback at all. A page-level toast is created on demand as a fallback.
	 */
	/*
	 * Feedback is owned by the shared module (assets/js/hsw-feedback.js).
	 * The product page used to carry its own toast plus an injected stylesheet;
	 * that is now one system, so the archive, the loop and the product page
	 * cannot disagree and the toast and the cart modal never both appear.
	 */
	function showAdded(btn, pid, res) {
		/*
		 * Mobile: the buy button becomes the stepper and a bottom sheet slides
		 * up with «کالا اضافه شد» + related products. Desktop keeps the button
		 * morph only — no sheet over the gallery.
		 */
		if (btn) { flashAdded(btn); }
		if (openSheet(pid)) { return; }

		/*
		 * The cart modal is opt-in on this page (HamiShop → کنترل ویجت‌ها):
		 * on a product page the visitor is already looking at what they added,
		 * so a dialog over the gallery is noise. Default is a plain toast.
		 */
		if (window.HSWFeedback && D.modal) {
			var titleEl = document.querySelector('.hsw-ptitle__h1, .hsw-ptitle__h2');
			window.HSWFeedback.addedToCart({
				fragments: res && res.fragments,
				cartUrl: D.cartUrl,
				message: D.addedText,
				productName: titleEl ? titleEl.textContent.trim() : '',
				style: D.feedbackStyle || 'modal',
				labels: {
					modalTitle: D.modalTitle,
					viewCart: D.viewCart,
					continue: D.continueText,
					close: D.closeText,
					added: D.addedText
				}
			});
			return;
		}
		if (btn) { flashAdded(btn); }
		if (window.HSWFeedback && D.addedText) {
			window.HSWFeedback.toast(D.addedText);
		}
	}

	/* ================= ADD-TO-CART SHEET (mobile) ================= */

	/*
	 * Bottom sheet shown right after an add on a phone: a success line, a link
	 * to the cart, and «خریدت رو کامل‌تر کن» with related products that can be
	 * added without leaving the page. Desktop never sees it.
	 */
	var sheetEl = null;
	var sheetBusy = false;

	function sheetAllowed() {
		return !!(D.sheet && D.relatedUrl) && window.matchMedia('(max-width: 767.98px)').matches;
	}

	/*
	 * What the /related endpoint sends is data, not markup: a product name is
	 * whatever was typed into the title field, and it was written into the
	 * sheet with innerHTML as is. Same rule as esc_html() on the PHP side —
	 * entities that are already there are kept, everything else is escaped.
	 */
	function sheetEsc(s) {
		return String(s == null ? '' : s)
			.replace(/&(?!(?:#[0-9]{1,7}|#[xX][0-9a-fA-F]{1,6}|[a-zA-Z][a-zA-Z0-9]{1,31});)/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

	function buildSheet() {
		if (sheetEl) { return sheetEl; }

		sheetEl = document.createElement('div');
		sheetEl.className = 'hsw-sheet';
		sheetEl.setAttribute('data-hsw-sheet', '');
		sheetEl.innerHTML =
			'<div class="hsw-sheet__backdrop" data-hsw-sheet-close></div>' +
			'<div class="hsw-sheet__panel" role="dialog" aria-modal="true" aria-label="' + (D.sheetAdded || '') + '">' +
				'<span class="hsw-sheet__grab" aria-hidden="true"></span>' +
				/* One row, facing each other: X + «کالا اضافه شد» on the right, cart pill on the left. */
				'<div class="hsw-sheet__head">' +
					'<span class="hsw-sheet__state">' +
						'<button type="button" class="hsw-sheet__x" data-hsw-sheet-close aria-label="' + (D.closeText || 'بستن') + '">' +
							'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"></path></svg>' +
						'</button>' +
						'<span class="hsw-sheet__ok"><span class="hsw-sheet__okic"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"></path></svg></span>' + (D.sheetAdded || '') + '</span>' +
					'</span>' +
					'<a class="hsw-sheet__cart" href="' + (D.cartUrl || '#') + '">' +
						'<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"></path></svg>' +
						(D.sheetCart || '') +
					'</a>' +
				'</div>' +
				'<p class="hsw-sheet__title">' + (D.sheetTitle || '') + '</p>' +
				'<div class="hsw-sheet__list" data-hsw-sheet-list></div>' +
			'</div>';

		document.body.appendChild(sheetEl);

		sheetEl.addEventListener('click', function (e) {
			if (e.target.closest('[data-hsw-sheet-close]')) { closeSheet(); return; }

			var add = e.target.closest('[data-hsw-sheet-add]');
			if (add) { sheetAdd(add); }
		});

		return sheetEl;
	}

	function openSheet(pid) {
		if (!sheetAllowed() || !pid) { return false; }
		buildSheet();

		/* The stepper lives in the sticky bar; the sheet must stop above it. */
		var bar = document.querySelector('.hsw-psticky');
		var gap = bar ? Math.round(bar.getBoundingClientRect().height) + 10 : 0;
		sheetEl.style.paddingBottom = gap ? gap + 'px' : '';

		sheetEl.classList.add('is-open');
		document.documentElement.classList.add('hsw-sheet-open');
		loadRelated(pid);
		return true;
	}

	function closeSheet() {
		if (!sheetEl) { return; }
		sheetEl.classList.remove('is-open');
		document.documentElement.classList.remove('hsw-sheet-open');
	}

	function loadRelated(pid) {
		var list = sheetEl.querySelector('[data-hsw-sheet-list]');
		if (!list) { return; }
		if (list.getAttribute('data-for') === String(pid)) { return; }
		list.setAttribute('data-for', String(pid));
		list.innerHTML = '<span class="hsw-sheet__loading"></span>';

		var url = D.relatedUrl + (D.relatedUrl.indexOf('?') > -1 ? '&' : '?') + 'product=' + encodeURIComponent(pid) + '&limit=4';

		fetch(url, { credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (res) {
				var items = (res && res.items) || [];
				if (!items.length) {
					list.innerHTML = '';
					sheetEl.classList.add('is-empty');
					return;
				}
				sheetEl.classList.remove('is-empty');
				/*
				 * A plain list: picture, name, price. No add button — the shopper
				 * adds with the stepper in the sticky bar, which stays above the
				 * sheet.
				 */
				list.innerHTML = items.map(function (p) {
					return '<a class="hsw-sheet__card" href="' + sheetEsc(p.url) + '">' +
						'<span class="hsw-sheet__media">' +
							(p.image ? '<img src="' + sheetEsc(p.image) + '" alt="" loading="lazy">' : '') +
						'</span>' +
						'<span class="hsw-sheet__body">' +
							'<span class="hsw-sheet__name">' + sheetEsc(p.name) + '</span>' +
							'<span class="hsw-sheet__price">' + sheetEsc(p.price) + '</span>' +
						'</span>' +
					'</a>';
				}).join('');
			})
			.catch(function () { list.innerHTML = ''; });
	}

	function sheetAdd(btn) {
		var id = btn.getAttribute('data-hsw-sheet-add');
		if (!id || btn.classList.contains('is-busy') || sheetBusy) { return; }
		sheetBusy = true;
		btn.classList.add('is-busy');

		var body = new URLSearchParams();
		body.set('product_id', id);
		body.set('quantity', '1');

		fetch(D.wcAjax || '/?wc-ajax=add_to_cart', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (r) { return r.json(); }).then(function (res) {
			sheetBusy = false;
			btn.classList.remove('is-busy');
			btn.classList.add('is-done');
			btn.textContent = '✓';
			if (res && res.fragments) { applyFragments(res.fragments); }
		}).catch(function () {
			sheetBusy = false;
			btn.classList.remove('is-busy');
		});
	}

	document.addEventListener('keydown', function (e) {
		if ('Escape' === e.key) { closeSheet(); }
	});

	/* ================= LIGHTBOX ================= */

	/*
	 * Full gallery lightbox: counter, arrows, keyboard, touch swipe, a thumbnail
	 * strip, and click-to-zoom (2.5x) with drag-to-pan for details.
	 */
	var zoomEl = null;
	var zoomList = [];
	var zoomIndex = 0;
	var zoomScale = 1;
	var panX = 0, panY = 0;
	/* True while the pointer actually dragged: the click that follows a pan
	   must not be treated as "toggle zoom" (the image jumped back to 1x). */
	var panMoved = false;

	function zoomBuild() {
		if (zoomEl) { return zoomEl; }
		zoomEl = document.createElement('div');
		zoomEl.className = 'hsw-zoom';
		var svgZoomIn = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.6-3.6M11 8v6M8 11h6"></path></svg>';
		var svgClose = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"></path></svg>';
		var svgPrev = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"></path></svg>';
		var svgNext = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"></path></svg>';

		zoomEl.innerHTML =
			'<div class="hsw-zoom__bar">' +
				'<span class="hsw-zoom__count" data-hsw-zoom-count></span>' +
				'<span class="hsw-zoom__tools">' +
					'<button type="button" class="hsw-zoom__btn" data-hsw-zoom-scale aria-label="بزرگ‌نمایی">' + svgZoomIn + '</button>' +
					'<button type="button" class="hsw-zoom__btn" data-hsw-zoom-close aria-label="بستن">' + svgClose + '</button>' +
				'</span>' +
			'</div>' +
			'<button type="button" class="hsw-zoom__nav hsw-zoom__nav--prev" data-hsw-zoom-prev aria-label="قبلی">' + svgPrev + '</button>' +
			'<button type="button" class="hsw-zoom__nav hsw-zoom__nav--next" data-hsw-zoom-next aria-label="بعدی">' + svgNext + '</button>' +
			'<div class="hsw-zoom__stage"><img class="hsw-zoom__img" alt=""></div>' +
			'<div class="hsw-zoom__thumbs" data-hsw-zoom-thumbs></div>';
		document.body.appendChild(zoomEl);

		zoomEl.addEventListener('click', function (e) {
			if (e.target.closest('[data-hsw-zoom-close]') || e.target === zoomEl) { closeZoom(); return; }
			/* Click / tap anywhere outside the picture closes the lightbox. */
			if (e.target.closest('.hsw-zoom__stage') && !e.target.closest('.hsw-zoom__img')) { closeZoom(); return; }
			if (e.target.closest('[data-hsw-zoom-prev]')) { zoomGo(-1); return; }
			if (e.target.closest('[data-hsw-zoom-next]')) { zoomGo(1); return; }
			if (e.target.closest('[data-hsw-zoom-scale]')) {
				zoomScale = zoomScale > 1 ? 1 : 2.5;
				panX = 0; panY = 0;
				zoomApply();
				return;
			}
			if (e.target.closest('.hsw-zoom__img')) {
				if (panMoved) { panMoved = false; return; }
				zoomScale = zoomScale > 1 ? 1 : 2.5;
				panX = 0; panY = 0;
				zoomApply();
				return;
			}
			var thumb = e.target.closest('[data-hsw-zoom-thumb]');
			if (thumb) { zoomShow(parseInt(thumb.getAttribute('data-hsw-zoom-thumb'), 10) || 0); }
		});
		return zoomEl;
	}

	function zoomApply() {
		var img = zoomEl.querySelector('.hsw-zoom__img');
		img.style.transform = 'translate(' + panX + 'px,' + panY + 'px) scale(' + zoomScale + ')';
		img.style.cursor = zoomScale > 1 ? 'grab' : 'zoom-in';
		zoomEl.classList.toggle('is-zoomed', zoomScale > 1);
	}

	function zoomShow(i) {
		if (!zoomList.length) { return; }
		zoomIndex = (i + zoomList.length) % zoomList.length;
		var img = zoomEl.querySelector('.hsw-zoom__img');
		img.src = zoomList[zoomIndex];
		zoomScale = 1; panX = 0; panY = 0;
		zoomApply();
		zoomEl.querySelector('[data-hsw-zoom-count]').textContent = fa(zoomIndex + 1) + ' / ' + fa(zoomList.length);
		zoomEl.querySelectorAll('[data-hsw-zoom-thumb]').forEach(function (b) {
			b.classList.toggle('is-active', parseInt(b.getAttribute('data-hsw-zoom-thumb'), 10) === zoomIndex);
		});
	}

	function zoomGo(dir) { zoomShow(zoomIndex + dir); }

	function openZoom(list, index) {
		zoomBuild();
		zoomList = Array.isArray(list) ? list : [list];
		var thumbs = zoomEl.querySelector('[data-hsw-zoom-thumbs]');
		thumbs.innerHTML = zoomList.map(function (src, i) {
			return '<button type="button" class="hsw-zoom__thumb" data-hsw-zoom-thumb="' + i + '"><img src="' + src + '" alt=""></button>';
		}).join('');
		thumbs.hidden = zoomList.length < 2;
		zoomShow(index || 0);
		zoomEl.classList.add('is-open');
		document.documentElement.classList.add('hsw-zoom-open');
	}

	function closeZoom() {
		if (!zoomEl) { return; }
		zoomEl.classList.remove('is-open');
		document.documentElement.classList.remove('hsw-zoom-open');
		zoomScale = 1; panX = 0; panY = 0;
	}

	document.addEventListener('keydown', function (e) {
		if (!zoomEl || !zoomEl.classList.contains('is-open')) { return; }
		if ('Escape' === e.key) { closeZoom(); }
		if ('ArrowLeft' === e.key) { zoomGo(-1); }
		if ('ArrowRight' === e.key) { zoomGo(1); }
	});

	/* Touch swipe + drag-to-pan inside the lightbox. */
	(function () {
		var sx = 0, sy = 0, dragging = false, moved = false;
		document.addEventListener('touchstart', function (e) {
			if (!zoomEl || !zoomEl.classList.contains('is-open') || e.touches.length !== 1) { return; }
			sx = e.touches[0].clientX; sy = e.touches[0].clientY;
			dragging = true; moved = false; panMoved = false;
		}, { passive: true });
		document.addEventListener('touchmove', function (e) {
			if (!dragging || !zoomEl || e.touches.length !== 1) { return; }
			var dx = e.touches[0].clientX - sx;
			var dy = e.touches[0].clientY - sy;
			if (Math.abs(dx) > 6 || Math.abs(dy) > 6) { moved = true; panMoved = true; }
			if (zoomScale > 1) {
				panX += e.touches[0].clientX - sx;
				panY += e.touches[0].clientY - sy;
				sx = e.touches[0].clientX; sy = e.touches[0].clientY;
				zoomApply();
			}
		}, { passive: true });
		document.addEventListener('touchend', function (e) {
			if (!dragging) { return; }
			dragging = false;
			if (zoomScale > 1 || !moved || !e.changedTouches.length) { return; }
			var dx = e.changedTouches[0].clientX - sx;
			if (Math.abs(dx) > 45) { zoomGo(dx > 0 ? -1 : 1); }
		}, { passive: true });

		/* Mouse drag to pan when zoomed. */
		var mx = 0, my = 0, mdrag = false, mdist = 0;
		document.addEventListener('mousedown', function (e) {
			if (!zoomEl || !zoomEl.classList.contains('is-open') || zoomScale <= 1) { return; }
			if (!e.target.closest('.hsw-zoom__img')) { return; }
			mdrag = true; mdist = 0; panMoved = false;
			mx = e.clientX; my = e.clientY;
			e.preventDefault();
		});
		document.addEventListener('mousemove', function (e) {
			if (!mdrag) { return; }
			var dx = e.clientX - mx;
			var dy = e.clientY - my;
			mdist += Math.abs(dx) + Math.abs(dy);
			if (mdist > 4) { panMoved = true; }
			panX += dx; panY += dy;
			mx = e.clientX; my = e.clientY;
			zoomApply();
		});
		document.addEventListener('mouseup', function () { mdrag = false; });
	})();

	/* ================= INIT ================= */
	function init() {
		/* seed variation payload roots */
		document.querySelectorAll('.hsw-p[data-hsw-variations]').forEach(function (root) {
			var pid = root.getAttribute('data-hsw-product') || root.getAttribute('data-hsw-variants');
			var st = state(pid);
			st.data = payload(root);

			var map = attrMap(root);
			/* preselect first active swatch / one active chip per group */
			var sw = root.querySelector('.hsw-pvar__swatch.is-active, .hsw-pvar__mswatch.is-active');
			if (sw) { st.color = sw.getAttribute('data-hsw-color') || ''; }

			st.chips = {};
			root.querySelectorAll('.hsw-pvar__chip.is-active, .hsw-pvar__mchip.is-active').forEach(function (b) {
				var tax = b.getAttribute('data-hsw-attr') || 'storage';
				var val = b.getAttribute('data-hsw-val') || b.getAttribute('data-hsw-storage') || '';
				if (!val) { return; }
				if (!st.chips[tax]) { st.chips[tax] = val; }
				if (map.storage === tax) { st.storage = val; }
			});

			applyVariant(pid, matchVariation(st.data, map, st));
		});

		/* Carousels (related products, gallery thumbs). init() runs on load and
		   again after every Elementor re-render, so this cannot be missed. */
		document.querySelectorAll('[data-hsw-carousel], .hsw-pgal__wrap').forEach(initCarousel);

		/* Product tabs: one strip, scrolls sideways on narrow screens. */
		document.querySelectorAll('[data-hsw-ptabs]').forEach(initTabs);
	}
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
	/* Elementor editor re-renders */
	if (window.jQuery) {
		window.jQuery(window).on('elementor/frontend/init', function () {
			window.elementorFrontend && window.elementorFrontend.hooks.addAction('frontend/element_ready/global', function () { init(); });
		});

	}

	/* ================= PRODUCT TABS ================= */

	/*
	 * The same tab strip on every screen. When it does not fit, it scrolls and a
	 * thin double-chevron appears at the reading edge; it fades away once the
	 * last tab is reached. Clicking a tab also centres it in the strip.
	 */
	function initTabs(root) {
		if (!root || root.getAttribute('data-hsw-tabs-ready') === '1') { return; }
		var nav = root.querySelector('[data-hsw-tabs-scroll]');
		if (!nav) { return; }
		root.setAttribute('data-hsw-tabs-ready', '1');

		var wrap = nav.closest('.hsw-ptabs__navwrap');
		var more = root.querySelector('[data-hsw-tabs-more]');

		function rtl() {
			return 'rtl' === (getComputedStyle(nav).direction || 'rtl');
		}

		function sync() {
			var max = nav.scrollWidth - nav.clientWidth;
			var scrollable = max > 4;
			if (wrap) { wrap.classList.toggle('is-scrollable', scrollable); }
			if (!more) { return; }
			var off = Math.abs(nav.scrollLeft);
			more.classList.toggle('is-off', !scrollable || off >= max - 4);
		}

		nav.addEventListener('scroll', sync, { passive: true });
		window.addEventListener('resize', sync);

		if (more) {
			more.addEventListener('click', function () {
				var step = Math.max(120, Math.round(nav.clientWidth * 0.6));
				nav.scrollBy({ left: rtl() ? -step : step, behavior: 'smooth' });
				setTimeout(sync, 340);
			});
		}

		root.querySelectorAll('[data-hsw-tab]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (nav.scrollWidth > nav.clientWidth + 4) {
					var navRect = nav.getBoundingClientRect();
					var btnRect = btn.getBoundingClientRect();
					var delta = (btnRect.left + btnRect.width / 2) - (navRect.left + navRect.width / 2);
					if (Math.abs(delta) > 8) {
						nav.scrollBy({ left: delta, behavior: 'smooth' });
					}
				}
				setTimeout(sync, 340);
			});
		});

		sync();
		setTimeout(sync, 200);

		if (root.classList.contains('hsw-ptabs--stack') || root.hasAttribute('data-hsw-ptabs-stack')) {
			initStackTabs(root, nav, wrap, sync);
		}
	}

	/*
	 * Style 2 (stacked sections + sticky header bar):
	 * - Detects the visible fixed/sticky main header (and WP admin bar) so the
	 *   tab strip stays cleanly spaced below it (--hsw-stk-top + --hsw-stk-gap).
	 * - Pins the tab strip while the user scrolls through the stacked panels and
	 *   unpins once the last panel passes.
	 * - Highlights the active tab button (with the subtle underline) as each
	 *   section enters the reading zone.
	 */
	function initStackTabs(root, nav, wrap, syncStrip) {
		if (!wrap || root.getAttribute('data-hsw-stack-ready') === '1') { return; }
		root.setAttribute('data-hsw-stack-ready', '1');

		var slot = root.querySelector('.hsw-ptabs__navslot') || wrap.parentElement;
		var panels = Array.prototype.slice.call(root.querySelectorAll('.hsw-ptabs__panel[data-hsw-panel]'));
		var buttons = Array.prototype.slice.call(root.querySelectorAll('.hsw-ptabs__btn[data-hsw-tab]'));
		if (!panels.length || !buttons.length) { return; }

		var activeId = '';
		var ticking = false;

		function gapPx() {
			var raw = getComputedStyle(root).getPropertyValue('--hsw-stk-gap') || '8px';
			var n = parseFloat(raw);
			return isNaN(n) ? 8 : Math.max(0, n);
		}

		function setActive(id) {
			if (!id || id === root._hswActiveId) { return; }
			root._hswActiveId = id;
			var activeBtn = null;
			buttons.forEach(function (b) {
				var on = b.getAttribute('data-hsw-tab') === id;
				b.classList.toggle('is-active', on);
				if (on) { activeBtn = b; }
			});
			if (activeBtn && nav.scrollWidth > nav.clientWidth + 4) {
				var navRect = nav.getBoundingClientRect();
				var btnRect = activeBtn.getBoundingClientRect();
				var delta = (btnRect.left + btnRect.width / 2) - (navRect.left + navRect.width / 2);
				if (Math.abs(delta) > 12) {
					nav.scrollBy({ left: delta, behavior: 'smooth' });
					if (typeof syncStrip === 'function') { setTimeout(syncStrip, 340); }
				}
			}
		}

		function update() {
			ticking = false;
			if (!root.offsetWidth) { return; }

			var hBottom = stackHeaderBottom();
			var gap = gapPx();
			var pinTop = hBottom + gap;
			var slotRect = (slot || root).getBoundingClientRect();
			var rootRect = root.getBoundingClientRect();
			var navH = wrap.offsetHeight || 56;

			root.style.setProperty('--hsw-stk-top', hBottom + 'px');
			root.style.setProperty('--hsw-stk-navh', navH + 'px');

			var shouldPin = slotRect.top <= pinTop && (rootRect.bottom - navH - 24) > pinTop;
			if (shouldPin) {
				if (slot) { slot.style.height = navH + 'px'; }
				wrap.classList.add('is-pinned');
				wrap.style.left = Math.round(rootRect.left) + 'px';
				wrap.style.width = Math.round(rootRect.width) + 'px';
			} else {
				wrap.classList.remove('is-pinned');
				wrap.style.left = '';
				wrap.style.width = '';
				if (slot) { slot.style.height = ''; }
			}

			if (root._hswLockUntil && Date.now() < root._hswLockUntil) {
				return;
			}

			/* Scrollspy: find the last panel whose top has crossed the reading line. */
			var probeY = pinTop + navH + 28;
			var chosen = panels[0].getAttribute('data-hsw-panel');
			for (var i = 0; i < panels.length; i++) {
				var pr = panels[i].getBoundingClientRect();
				if (pr.top <= probeY) {
					chosen = panels[i].getAttribute('data-hsw-panel');
				}
			}
			setActive(chosen);
		}

		function requestUpdate() {
			if (!ticking) {
				ticking = true;
				window.requestAnimationFrame(update);
			}
		}

		window.addEventListener('scroll', requestUpdate, { passive: true });
		window.addEventListener('resize', requestUpdate, { passive: true });
		update();
		setTimeout(update, 250);
	}

	/* ================= CAROUSEL ================= */

	/*
	 * RTL-aware horizontal carousel: arrow buttons scroll by one card, the edge
	 * fade only shows while there is more content in that direction, and mouse
	 * drag works on desktop (touch scrolls natively).
	 */
	function initCarousel(root) {
		if (!root || root.getAttribute('data-hsw-carousel-ready') === '1') { return; }
		var track = root.querySelector('[data-hsw-track]') || root.querySelector('.hsw-pgal__thumbs');
		if (!track) { return; }
		root.setAttribute('data-hsw-carousel-ready', '1');

		var prev = root.querySelector('[data-hsw-nav="prev"]');
		var next = root.querySelector('[data-hsw-nav="next"]');
		var fadeNext = root.querySelector('[data-hsw-fade="next"]');
		var fadePrev = root.querySelector('[data-hsw-fade="prev"]');

		function rtl() {
			return 'rtl' === (getComputedStyle(track).direction || 'rtl');
		}

		/* In RTL scrollLeft goes negative; normalise to "distance from start". */
		function offset() {
			return rtl() ? Math.abs(track.scrollLeft) : track.scrollLeft;
		}

		function maxOffset() {
			return Math.max(0, track.scrollWidth - track.clientWidth);
		}

		function sync() {
			var atStart = offset() <= 2;
			var atEnd = offset() >= maxOffset() - 2;
			/* «next» = further along the reading direction (left in RTL). */
			if (fadeNext) { fadeNext.classList.toggle('is-on', !atEnd); }
			if (fadePrev) { fadePrev.classList.toggle('is-on', !atStart); }
			if (next) { next.disabled = atEnd; }
			if (prev) { prev.disabled = atStart; }
			/* The right fade only matters when we can go back. */
			if (fadePrev) { fadePrev.hidden = atStart; }
		}

		function step(dir) {
			var card = track.firstElementChild;
			var w = card ? card.getBoundingClientRect().width + 16 : track.clientWidth * 0.8;
			var delta = Math.max(w, 60) * (dir === 'next' ? 1 : -1);
			/* RTL: scrolling left means a negative scrollLeft. */
			var sign = rtl() ? -1 : 1;
			track.scrollBy({ left: delta * sign, behavior: 'smooth' });
			setTimeout(sync, 350);
		}

		if (next) { next.addEventListener('click', function () { step('next'); }); }
		if (prev) { prev.addEventListener('click', function () { step('prev'); }); }
		track.addEventListener('scroll', sync, { passive: true });
		window.addEventListener('resize', sync);
		sync();
		/* Flex widths are only final after layout/images settle. */
		setTimeout(sync, 150);
		track.querySelectorAll('img').forEach(function (img) {
			if (img.complete) { return; }
			img.addEventListener('load', sync, { once: true });
		});

		/* Mouse drag (desktop). Touch already scrolls natively. */
		var down = false, startX = 0, startScroll = 0, moved = 0;
		track.addEventListener('mousedown', function (e) {
			if (e.button !== 0) { return; }
			down = true; moved = 0;
			startX = e.pageX;
			startScroll = track.scrollLeft;
			track.style.cursor = 'grabbing';
		});
		window.addEventListener('mousemove', function (e) {
			if (!down) { return; }
			var dx = e.pageX - startX;
			if (Math.abs(dx) > 3) { moved = 1; }
			track.scrollLeft = startScroll - dx;
		});
		window.addEventListener('mouseup', function () {
			if (!down) { return; }
			down = false;
			track.style.cursor = '';
			if (moved) {
				/* Suppress the click that follows a drag. */
				track.addEventListener('click', function stop(ev) {
					ev.preventDefault();
					ev.stopPropagation();
					track.removeEventListener('click', stop, true);
				}, true);
			}
			sync();
		});
	}
})();
